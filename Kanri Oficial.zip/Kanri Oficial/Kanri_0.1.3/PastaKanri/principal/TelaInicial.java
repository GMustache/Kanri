package principal;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;

import pagamentos.TelaPagamento;
import mencoes.TelaMencoes;
import turmas.TelaTurmas;
import alunos.TelaAlunos;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
public class TelaInicial extends JFrame {

	private TelaAlunos telaAlunos;
	private TelaMencoes telaMencoes;
	private TelaTurmas telaTurmas;

	private JPanel contentPane;
	private TelaPagamento telaPagamentos;
	
	public TelaInicial(String usuario) {
		
		setTitle("Kanri - Menu");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		contentPane = new JPanel();
		contentPane.setForeground(Color.BLACK);
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel pHead = new JPanel();
		pHead.setForeground(new Color(102, 255, 102));
		pHead.setBackground(new Color(102, 255, 51));
		pHead.setBounds(10, 11, 574, 60);
		contentPane.add(pHead);
		pHead.setLayout(null);
		
		JLabel lblUsurio = new JLabel("Usu\u00E1rio:" + usuario);
		lblUsurio.setForeground(Color.WHITE);
		lblUsurio.setFont(new Font("Gulim", Font.PLAIN, 25));
		lblUsurio.setBounds(10, 11, 250, 38);
		pHead.add(lblUsurio);
		
		JButton btnNewButton = new JButton("Turmas");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent abrirTelaTurmas) {
				
				abrirTelaTurmas();
				
			}
		});
		btnNewButton.setFont(new Font("Copperplate Gothic Light", Font.PLAIN, 15));
		btnNewButton.setForeground(new Color(102, 255, 51));
		btnNewButton.setBackground(new Color(128, 128, 128));
		btnNewButton.setBounds(466, 11, 98, 38);
		pHead.add(btnNewButton);
		
		JPanel pBody = new JPanel();
		pBody.setBackground(Color.WHITE);
		pBody.setBounds(10, 81, 574, 279);
		contentPane.add(pBody);
		pBody.setLayout(null);
		
		JPanel pAlunos = new JPanel();
		pAlunos.setBackground(Color.DARK_GRAY);
		pAlunos.setBounds(12, 12, 175, 255);
		pBody.add(pAlunos);
		pAlunos.setLayout(null);
		
		JLabel icoAlunos = new JLabel("");
		icoAlunos.setFont(new Font("Copperplate Gothic Light", Font.PLAIN, 17));
		icoAlunos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent abrirTelaAlunos) {
				
				abrirTelaAlunos();
				
			}
		});
		icoAlunos.setIcon(new ImageIcon("E:\\Kanri 0.1.2\\Imagens\\icoAlunos.png"));
		icoAlunos.setBounds(0, 0, 175, 255);
		pAlunos.add(icoAlunos);
		
		JPanel pMencoes = new JPanel();
		pMencoes.setBackground(Color.DARK_GRAY);
		pMencoes.setBounds(200, 12, 175, 255);
		pBody.add(pMencoes);
		pMencoes.setLayout(null);
		
		JLabel icoMencoes = new JLabel("");
		icoMencoes.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent abrirTelaMencoes) {
				
				abrirTelaMencoes();
				
			}
		});
		icoMencoes.setIcon(new ImageIcon("E:\\Kanri 0.1.2\\Imagens\\icoMencoes.png"));
		icoMencoes.setBounds(0, 0, 175, 255);
		pMencoes.add(icoMencoes);
		
		JPanel pPagamentos = new JPanel();
		pPagamentos.setBackground(Color.DARK_GRAY);
		pPagamentos.setBounds(387, 12, 175, 255);
		pBody.add(pPagamentos);
		pPagamentos.setLayout(null);
		
		JLabel icoPagamentos = new JLabel("");
		icoPagamentos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				abrirTelaPagamentos();
				
			}
		});
		icoPagamentos.setBounds(0, 0, 175, 256);
		pPagamentos.add(icoPagamentos);
	}
	
	private void abrirTelaPagamentos(){
		
		if(telaPagamentos == null)
		{
			try {
				telaPagamentos = new TelaPagamento();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		telaPagamentos.setVisible(true);
	}
	
	private void abrirTelaAlunos(){
		
		if(telaAlunos == null)
		{
		 telaAlunos= new TelaAlunos();
		}
		 telaAlunos.setVisible(true);
	}
	
	private void abrirTelaMencoes(){
		
		if(telaMencoes == null)
		{
		 telaMencoes= new TelaMencoes();
		}
		 telaMencoes.setVisible(true);
	}
	
	private void abrirTelaTurmas()
	{
		if(telaTurmas == null)
		{
			telaTurmas = new TelaTurmas();
		}
		telaTurmas.setVisible(true);
	}
}
