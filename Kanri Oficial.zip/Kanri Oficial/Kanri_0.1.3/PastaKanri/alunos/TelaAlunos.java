package alunos;

import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JMenuBar;
import javax.swing.JTextField;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;

import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import javax.swing.JLabel;


import dao.ClasseComandos;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

public class TelaAlunos extends JFrame {

	private static final long serialVersionUID = 1L;

	private TelaAlunosCadastrar telaAlunosCadastrar;
	private TelaAlunosAlterar telaAlunosAlterar;
	private TelaMatricula telaMatricula;
	
	private JPanel contentPane;
	private JTable tableAlunos;
	private DefaultTableModel dtm;
	private DefaultTableModel dtm2;
	//private String location;
	private JTextField txtPesquisar;
	
	private String pesquisa = "RM";
	private String  textopesq = "Pesquisar" + "(" + pesquisa + ")";
	private JTable tableTurmas;

	
	
	public TelaAlunos() {
		
		setResizable(false);
		setTitle("Kanri - Gerenciar Alunos");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		
		dtm = new DefaultTableModel(new String[][] {{
			
		}},
			new String[] {
				"RM", "Nome","Data de Nascimento", "RG", "Telefone", "Endere�o", "Data de Pagamento"
		});
	
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
			
		JMenuItem mnAtualizar = new JMenuItem("Atualizar");
		mnAtualizar.setFont(new Font("Copperplate Gothic Light", Font.PLAIN, 15));
		mnAtualizar.setForeground(Color.WHITE);
		mnAtualizar.setBackground(Color.DARK_GRAY);
		mnAtualizar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
		mnAtualizar.addActionListener(new ActionListener() {	
			public void actionPerformed(ActionEvent atualizarTelaAlunos) {
				
				txtPesquisar.setText(textopesq);
				telaAtualizarAluno(dtm);
				
			}
		});
		
		menuBar.add(mnAtualizar);
		
		JMenuItem mntmRelatrio = new JMenuItem("Relat\u00F3rio");
		mntmRelatrio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent gerarRelafuckingtoriomamOMFG) {
				
				txtPesquisar.setText(textopesq);
				gerarRelatorio();
						
			}
		});
		mntmRelatrio.setFont(new Font("Gulim", Font.PLAIN, 15));
		mntmRelatrio.setForeground(Color.WHITE);
		mntmRelatrio.setBackground(new Color(102, 153, 102));
		menuBar.add(mntmRelatrio);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		dtm2 = new DefaultTableModel( new String[][] {{
			
		}},
			new String[] {
				"Turma", "Disciplina","Semestre"
		});
		tableTurmas = new JTable(dtm2)
{
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column) {
				
				return false;
				
			}
		};
		
		JPanel pNovices = new JPanel();
		pNovices.setBackground(Color.DARK_GRAY);
		pNovices.setBounds(12, 12, 770, 400);
		contentPane.add(pNovices);
		pNovices.setLayout(null);
		
		JScrollPane scrollPaneAlunos = new JScrollPane();
		scrollPaneAlunos.setBounds(0, 44, 770, 343);
		pNovices.add(scrollPaneAlunos);

		tableAlunos = new JTable(dtm){
			
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column) {
				
				return false;
				
			}
		};
		tableAlunos.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent carregaTurmas) {
				
				ClasseComandos cmdAtualizaTurmasAluno = new ClasseComandos();
				cmdAtualizaTurmasAluno.atualizarTurmas2(dtm2, Integer.parseInt((String)dtm.getValueAt(tableAlunos.getSelectedRow(), 0)));				
				
			}
		});
		tableAlunos.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		scrollPaneAlunos.setViewportView(tableAlunos);		
		
		JButton btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				telaPesquisaAlunos(txtPesquisar.getText(), dtm, pesquisa);
			
			}

		});
		btnPesquisar.setBackground(new Color(102, 255, 51));
		btnPesquisar.setForeground(Color.WHITE);
		btnPesquisar.setFont(new Font("Gulim", Font.PLAIN, 15));
		btnPesquisar.setBounds(655, 11, 103, 26);
		pNovices.add(btnPesquisar);		
		
		String[] tipopesquisa = new String[2];
	    tipopesquisa[0] = "RM";
	    tipopesquisa[1] = "Nome";
		
		JComboBox<?> jcbTipoPesquisa = new JComboBox<Object>(tipopesquisa);
		jcbTipoPesquisa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				pesquisa = jcbTipoPesquisa.getSelectedItem().toString();
				telaAtualizarAluno(dtm);
				textopesq = "Pesquisar" + "(" + pesquisa + ")";
				txtPesquisar.setText(textopesq);
				
			}
		});
		jcbTipoPesquisa.setFont(new Font("Gulim", Font.PLAIN, 14));
		jcbTipoPesquisa.setBackground(Color.WHITE);
		jcbTipoPesquisa.setBounds(10, 12, 105, 25);
		pNovices.add(jcbTipoPesquisa);
		
		txtPesquisar = new JTextField();
		txtPesquisar.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				
				
				if(txtPesquisar.getText().equals("Pesquisar(RM)") || txtPesquisar.getText().equals("Pesquisar(Nome)"))
				{
				txtPesquisar.setText("");
				}
			}
		});
		txtPesquisar.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		txtPesquisar.setText(textopesq);
		txtPesquisar.setBounds(124, 12, 460, 25);
		pNovices.add(txtPesquisar);
		txtPesquisar.setColumns(10);
		
		JButton btnX = new JButton("X");
		btnX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	
				textopesq = "Pesquisar" + "(" + pesquisa + ")";
				txtPesquisar.setText(textopesq);
				telaAtualizarAluno(dtm);
				
			}
			
		});
		btnX.setToolTipText("Limpar pesquisa");
		btnX.setForeground(Color.WHITE);
		btnX.setFont(new Font("Castellar", Font.BOLD, 10));
		btnX.setBackground(new Color(0, 153, 51));
		btnX.setBounds(598, 11, 45, 26);
		pNovices.add(btnX);
		
		JPanel pButtonsAlunos = new JPanel();
		pButtonsAlunos.setForeground(Color.DARK_GRAY);
		pButtonsAlunos.setBackground(Color.DARK_GRAY);
		pButtonsAlunos.setBounds(12, 424, 770, 136);
		contentPane.add(pButtonsAlunos);
		pButtonsAlunos.setLayout(null);
		
		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent abrirTelaAlunosCadastrar) {
				
				txtPesquisar.setText(textopesq);
				abrirTelaAlunosCadastrar(dtm);
			    telaAtualizarAluno(dtm);
			}
			
		
			
		});
		btnCadastrar.setForeground(Color.WHITE);
		btnCadastrar.setFont(new Font("Gulim", Font.BOLD, 35));
		btnCadastrar.setBackground(new Color(102, 255, 51));
		btnCadastrar.setBounds(10, 40, 240, 50);
		pButtonsAlunos.add(btnCadastrar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				
					txtPesquisar.setText(textopesq);
				
					try{
					telaExcluirAluno();
					}
					catch(IndexOutOfBoundsException X)
					{
					JOptionPane.showMessageDialog(null, "Selecione uma linha para alterar!", "Erro", JOptionPane.ERROR_MESSAGE);	
					}
					
					telaAtualizarAluno(dtm);
			}});
		btnExcluir.setForeground(Color.WHITE);
		btnExcluir.setFont(new Font("Gulim", Font.BOLD, 35));
		btnExcluir.setBackground(new Color(102, 255, 51));
		btnExcluir.setBounds(520, 40, 240, 50);
		pButtonsAlunos.add(btnExcluir);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtPesquisar.setText(textopesq);
				
				try{
				abrirTelaAlunosAlterar(dtm);
				}
				catch(IndexOutOfBoundsException x)
				{
				JOptionPane.showMessageDialog(null, "Selecione uma linha para alterar!", "Erro", JOptionPane.ERROR_MESSAGE);	
				}
				
				telaAtualizarAluno(dtm);
			}
		});
		btnAlterar.setForeground(Color.WHITE);
		btnAlterar.setFont(new Font("Gulim", Font.BOLD, 35));
		btnAlterar.setBackground(new Color(102, 255, 51));
		btnAlterar.setBounds(265, 40, 240, 50);
		pButtonsAlunos.add(btnAlterar);
		
		JPanel pClasses = new JPanel();
		pClasses.setBackground(Color.BLACK);
		pClasses.setBounds(794, 12, 200, 400);
		contentPane.add(pClasses);
		pClasses.setLayout(null);
		
		JScrollPane scrollPaneTurmas = new JScrollPane();
		scrollPaneTurmas.setBounds(0, 40, 200, 348);
		pClasses.add(scrollPaneTurmas);
		
		
		scrollPaneTurmas.setViewportView(tableTurmas);
		
		
		JLabel lblMatriculas = new JLabel("Matriculas:");
		lblMatriculas.setHorizontalAlignment(SwingConstants.CENTER);
		lblMatriculas.setForeground(Color.WHITE);
		lblMatriculas.setFont(new Font("Gulim", Font.PLAIN, 25));
		lblMatriculas.setBounds(0, 0, 200, 41);
		pClasses.add(lblMatriculas);
		
		JPanel pButtonsTurmas = new JPanel();
		pButtonsTurmas.setBackground(Color.DARK_GRAY);
		pButtonsTurmas.setBounds(794, 424, 200, 123);
		contentPane.add(pButtonsTurmas);
		pButtonsTurmas.setLayout(null);
		
		JButton btnMatricular = new JButton("Matricular");
		btnMatricular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent abrirTelaMatricula) {
				
				
				try{
					
				txtPesquisar.setText(textopesq);
				
				telaMatricula = new TelaMatricula(Integer.parseInt((String) dtm.getValueAt(tableAlunos.getSelectedRow(), 0)), String.valueOf(dtm.getValueAt(tableAlunos.getSelectedRow(), 1)), dtm2);		
				telaMatricula.setVisible(true);
				}catch(IndexOutOfBoundsException x)
				{
				JOptionPane.showMessageDialog(null, "Selecione uma linha para matricular!", "Erro", JOptionPane.ERROR_MESSAGE);	
				}
				
				telaAtualizarAluno(dtm);
			}
		});
		btnMatricular.setFont(new Font("Gulim", Font.PLAIN, 20));
		btnMatricular.setForeground(Color.WHITE);
		btnMatricular.setBackground(new Color(102, 153, 102));
		btnMatricular.setBounds(12, 13, 176, 45);
		pButtonsTurmas.add(btnMatricular);
		
		JButton btnRemover = new JButton("Remover");
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent removerAluno) {
				
				try{
					
				txtPesquisar.setText(textopesq);	
				
				ClasseComandos cmdRemover = new ClasseComandos();
				cmdRemover.removerMatricula(Integer.parseInt(dtm.getValueAt(tableAlunos.getSelectedRow(), 0).toString()), Integer.parseInt(dtm2.getValueAt(tableTurmas.getSelectedRow(), 0).toString()));
				telaAtualizarTurmas(dtm2, Integer.parseInt(dtm.getValueAt(tableAlunos.getSelectedRow(), 0).toString()));
				}
				catch(IndexOutOfBoundsException x)
				{
				JOptionPane.showMessageDialog(null, "Selecione uma linha para remover!", "Erro", JOptionPane.ERROR_MESSAGE);	
				}
				
			}
		});
		btnRemover.setForeground(Color.WHITE);
		btnRemover.setFont(new Font("Gulim", Font.PLAIN, 20));
		btnRemover.setBackground(new Color(102, 153, 102));
		btnRemover.setBounds(12, 65, 176, 45);
		pButtonsTurmas.add(btnRemover);
			
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent evt) {
		
				telaAtualizarAluno(dtm);
				txtPesquisar.setText(textopesq);
				
			}
			});
		
		telaAtualizarAluno(dtm);
		
	}
	
	// Comandos internos
	

	private void abrirTelaAlunosCadastrar(DefaultTableModel dtm){
		
		if(telaAlunosCadastrar == null)
		{
			telaAlunosCadastrar = new TelaAlunosCadastrar(dtm);
		}
		 telaAlunosCadastrar.setVisible(true);
		
	}
	
	private void abrirTelaAlunosAlterar(DefaultTableModel dtm)
	{
		 telaAlunosAlterar = new TelaAlunosAlterar((String) dtm.getValueAt(tableAlunos.getSelectedRow(), 1), (String) dtm.getValueAt(tableAlunos.getSelectedRow(), 3), (String) dtm.getValueAt(tableAlunos.getSelectedRow(), 5), (String) dtm.getValueAt(tableAlunos.getSelectedRow(), 2), (String) dtm.getValueAt(tableAlunos.getSelectedRow(), 4), (String) dtm.getValueAt(tableAlunos.getSelectedRow(), 0), (String) dtm.getValueAt(tableAlunos.getSelectedRow(), 6), dtm);
		
		 // N�o funciona como o esperado
		 if(telaAlunosAlterar.isVisible() == false)
		 {
		 telaAlunosAlterar.setVisible(true);
		 }
	}
	
	private void gerarRelatorio(){
		
		try {
			
			HashMap parametros = new HashMap();
			
			JasperPrint escrevedor;
		
			String localdorelatorio = "E:/Henrique/TCC/Kanri 0.1.3/Jasper/Relatorios/MyReports/alunos.jasper";

			String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
				
			Connection conexaorelatorio = DriverManager.getConnection(url, "root", "");
		
			
			// Enche o relat�rio
			
			escrevedor = JasperFillManager.fillReport(localdorelatorio, parametros, conexaorelatorio);
		  
			// JasperExportManager.exportReportToPdfFile(localdorelatorio);
			JasperViewer vizualizador = new JasperViewer(escrevedor, false);
			
			 vizualizador.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			 vizualizador.setSize(800, 600);
			 vizualizador.setExtendedState(MAXIMIZED_BOTH);
			 vizualizador.setVisible(true);


		}catch (SQLException | JRException e) {
		e.printStackTrace();
		}
	
	}
	
	// Comandos externos
	
	public void telaExcluirAluno()
	{
			
				String selecionaRM = (String) dtm.getValueAt(tableAlunos.getSelectedRow(), 0);
					
				System.out.println(selecionaRM);
				
				if(!selecionaRM.equals("") || !selecionaRM.equals(null))
				{
								
				int resp = JOptionPane.showConfirmDialog(null, "Deseja mesmo excluir esse aluno?", "Confirma��o",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				
				if(resp == 0)
				{
				
					ClasseComandos cmdExcluir = new ClasseComandos();
					cmdExcluir.excluirAluno(selecionaRM);
							
				}
				}
				
				telaAtualizarAluno(dtm);
				
	}

	public void telaAtualizarAluno(DefaultTableModel modelo) {
		
			ClasseComandos cmdAtualizar = new ClasseComandos();
			cmdAtualizar.atualizarAluno(dtm);			
			txtPesquisar.setText(textopesq);			
	}

	private void telaPesquisaAlunos(String pesquisa, DefaultTableModel modelo, String tipopesquisa) {

		if(!txtPesquisar.getText().equals("Pesquisar(RM)") && !txtPesquisar.getText().equals("Pesquisar(Nome)") && !txtPesquisar.getText().equals(""))
		{
		
		ClasseComandos cmdPesquisar = new ClasseComandos();
		cmdPesquisar.pesquisarAluno(pesquisa, modelo, tipopesquisa);
		
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Insira algum dado!", "Aten��o!", JOptionPane.ERROR_MESSAGE);
		}
		
	}
	
	public void telaAtualizarTurmas(DefaultTableModel modelo, int RM)
	{
		ClasseComandos cmdAtualizar = new ClasseComandos();
		cmdAtualizar.atualizarTurmas2(modelo, RM);
	}
}