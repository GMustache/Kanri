package alunos;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.Font;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComboBox;

import dao.ClasseComandos;
import bean.Turma;

import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;

public class TelaMatricula extends JDialog {


	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JTextField txtRM;
	private JTextField txtNome;
	
	private List<Turma> listadeturmas = new ArrayList<Turma>();

	DefaultTableModel dtm;
	
	public TelaMatricula(int RM, String nome, DefaultTableModel dtm) {
		
		this.dtm = dtm;
		
		setResizable(false);
		setTitle("Kanri - Matricula");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(Color.DARK_GRAY);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
	
		ClasseComandos cmdAtualizaTurmas = new ClasseComandos();
		cmdAtualizaTurmas.atualizarTurmas(listadeturmas);
		
		JComboBox<Integer> jcbTurmas = new JComboBox<Integer>();
		for(Turma turma : listadeturmas)
		{
				jcbTurmas.addItem(turma.getCod());
		}
		jcbTurmas.setBackground(new Color(102, 153, 102));
		jcbTurmas.setForeground(Color.WHITE);
		jcbTurmas.setFont(new Font("Segoe UI Light", Font.PLAIN, 25));
		jcbTurmas.setBounds(10, 148, 414, 35);
		contentPanel.add(jcbTurmas);
		
		JLabel lblRM = new JLabel("RM:");
		lblRM.setFont(new Font("Gulim", Font.PLAIN, 15));
		lblRM.setForeground(Color.WHITE);
		lblRM.setBounds(10, 11, 46, 14);
		contentPanel.add(lblRM);
		
		txtRM = new JTextField();
		txtRM.setEnabled(false);
		txtRM.setEditable(false);
		txtRM.setBounds(10, 36, 70, 20);
		txtRM.setText(String.valueOf(RM));
		contentPanel.add(txtRM);
		txtRM.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setForeground(Color.WHITE);
		lblNome.setFont(new Font("Gulim", Font.PLAIN, 15));
		lblNome.setBounds(10, 67, 46, 14);
		contentPanel.add(lblNome);
		
		txtNome = new JTextField();
		txtNome.setEnabled(false);
		txtNome.setEditable(false);
		txtNome.setColumns(10);
		txtNome.setBounds(10, 92, 414, 20);
		txtNome.setText(nome);
		contentPanel.add(txtNome);
		
		JLabel lblTurmas = new JLabel("Turma:");
		lblTurmas.setForeground(Color.WHITE);
		lblTurmas.setFont(new Font("Gulim", Font.PLAIN, 15));
		lblTurmas.setBounds(10, 123, 46, 14);
		contentPanel.add(lblTurmas);	
	
		JPanel pButtons = new JPanel();
		pButtons.setBackground(Color.GRAY);
		pButtons.setBounds(0, 222, 444, 50);
		contentPanel.add(pButtons);
		pButtons.setLayout(null);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			dispose();
				
			}
		});
		btnCancelar.setForeground(Color.WHITE);
		btnCancelar.setFont(new Font("Gulim", Font.BOLD, 22));
		btnCancelar.setBackground(new Color(102, 255, 51));
		btnCancelar.setBounds(234, 12, 198, 26);
		pButtons.add(btnCancelar);
		
		JButton btnMatricular = new JButton("Matricular");
		btnMatricular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent clickMatricula) {
			
				telaMatricularAluno(Integer.parseInt(txtRM.getText()), (int) jcbTurmas.getSelectedItem());
			}
		});
		btnMatricular.setForeground(Color.WHITE);
		btnMatricular.setFont(new Font("Gulim", Font.BOLD, 22));
		btnMatricular.setBackground(new Color(102, 255, 51));
		btnMatricular.setBounds(12, 12, 198, 26);
		pButtons.add(btnMatricular);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent evt) {

				jcbTurmas.setSelectedIndex(0);
			}
			});
	}

	private void telaMatricularAluno(int RM, int Turma)
	{
	ClasseComandos cmdMatricular = new ClasseComandos();
	
	int resp = JOptionPane.showConfirmDialog(this, "Confirmar matricula?", "Confirma��o", JOptionPane.PLAIN_MESSAGE);
	
	if(resp == 0)
	{
	cmdMatricular.matricularAluno(RM, Turma, this);
	cmdMatricular.atualizarTurmas2(dtm, RM);
	
	}
	}
}
