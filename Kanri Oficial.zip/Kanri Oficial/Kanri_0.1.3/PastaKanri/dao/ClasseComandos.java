package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import principal.TelaInicial;
import turmas.TelaTurmasAlterar;
import turmas.TelaTurmasCadastrar;
import alunos.TelaMatricula;
import bean.Disciplina;
import bean.Mencao;
import bean.Turma;

public class ClasseComandos {
	
	
	// Tela Login X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X
	
	public void logar(String usuario, String senha, JFrame frame, JTextField txtusuario, JTextField txtsenha){
	
		try {
		
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				JOptionPane.showMessageDialog(null, "Erro ao encontrar o driver MySQL!\nErro:" + e, "Falha na conex�o!", JOptionPane.ERROR_MESSAGE);
			}
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = "SELECT * FROM `logaradm`";
	      
		Connection conexao;
		
		try {
			conexao = DriverManager.getConnection(url, "root", "");
			
			Statement St = conexao.createStatement();
			ResultSet Rs = St.executeQuery(sql);
				
			boolean logado = false;
			
				while(Rs.next())
				{
					if(usuario.equals(Rs.getString("adm")) && senha.equals(Rs.getString("senha")))
					{
						TelaInicial telaInicial = new TelaInicial(usuario);
						telaInicial.setVisible(true);
						frame.dispose();
						logado = true;
						
						 St.close();
						 Rs.close();
			     		 conexao.close();
					}			
				}
				
				if(logado == false)
				{
					JOptionPane.showMessageDialog(null, "Usu�rio ou senha inv�lidos!", "Falha no login!", JOptionPane.ERROR_MESSAGE);
					txtusuario.setText("");
					txtsenha.setText("");
				}
			
		} catch (SQLException e) {
			if(!e.getMessage().equals("Operation not allowed after ResultSet closed"))
			mensagemDeErro(e);
		}

		}
		catch(NumberFormatException e )
		{
			JOptionPane.showMessageDialog(null, "Voc� precisa inserir de acordo com a formata��o!", "Erro", JOptionPane.ERROR_MESSAGE
					);
		}
	}

	
	// Tela Alunos X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-
	
	
	public void cadastrarAluno(String nome, String RG, String endereco, String datanasc, String telefone, String foto, String datapag, String xsenha)
	{
	
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Erro ao encontrar o driver MySQL!\nErro:" + e, "Falha na conex�o!", JOptionPane.ERROR_MESSAGE);
		}
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      
	      
	      String sql = "INSERT INTO `u157866330_kanri`.`alunos` (`Rm`, `Nome`, `Datanasc`, `RG`, `Telefone`, `Endereco`, `Datapagamento`, `Foto`, `Senha`) VALUES (NULL, '" + nome + "', '" + datanasc + "', '" + RG + "', '" + telefone + "', '" + endereco + "', '" + datapag + "', '', '" + xsenha + "');";
	      
	     
	      Connection conexao;
	      

		try {
		
			conexao = DriverManager.getConnection(url, "root", "");
			
		Statement St = conexao.createStatement();
	     St.executeUpdate(sql);
	     
	     JOptionPane.showMessageDialog(null, "Aluno cadastrado!", "Sucesso", JOptionPane.PLAIN_MESSAGE);
	     
	     St.close();
	     conexao.close();
	     
		} catch (SQLException e) {
			mensagemDeErro(e);
			}
	     
	}
	
	
	public void alterarAluno(String nome, String RG, String endereco, String datanasc, String telefone, String RM, String datapag)
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Erro ao encontrar o driver MySQL!\nErro:" + e, "Falha na conex�o!", JOptionPane.ERROR_MESSAGE);
		}
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = "UPDATE `u157866330_kanri`.`alunos` SET `Nome` = '" + nome+ "', `Datanasc` = '" + datanasc + "', `RG` = '" + RG+ "', `Telefone` = '" + telefone + "', `Endereco` = '" + endereco + "', `Datapagamento` = '" + datapag + "' WHERE `alunos`.`Rm` = " + RM + ";";
	      
	      Connection conexao;
		try {
			conexao = DriverManager.getConnection(url, "root", "");
			
			 Statement St = conexao.createStatement();
		     St.executeUpdate(sql);
		     
		     JOptionPane.showMessageDialog(null, "Aluno alterado!", "Sucesso", JOptionPane.PLAIN_MESSAGE);
		     
		     St.close();
			 conexao.close();
		     
		} catch (SQLException e) {
			mensagemDeErro(e);
		}
	
	    
	     
	}
	
	
	public void excluirAluno(String selecionaRM) {
		
		if(!selecionaRM.equals(""))
		{
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				mensagemDeErro(e);
				}

			String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	        
			Connection conexao;
			try {
				
				conexao = (Connection) DriverManager.getConnection(url, "root", "");
			
				Statement St = conexao.createStatement();
		        St.executeUpdate("DELETE FROM `u157866330_kanri`.`alunos` WHERE `alunos`.`Rm` = " + selecionaRM + ";");
		        						
		        JOptionPane.showMessageDialog(null, "Aluno exclu�do!", "Sucesso", JOptionPane.PLAIN_MESSAGE);
		        
		       
		        St.close();
			    conexao.close();
			     
			} catch (SQLException e) {
				mensagemDeErro(e);
			}

		}
		else
		{
			JOptionPane.showMessageDialog(null, "Preencha o campo!", "Aten��o!", JOptionPane.ERROR_MESSAGE);
		}	
		
	}
	
	
	public void atualizarAluno(DefaultTableModel modelo)
	{
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			mensagemDeErro(e);
			}
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = "select * from alunos order by nome";
	
	      Connection conexao;
		try {
			
		  conexao = DriverManager.getConnection(url, "root", "");
				      
	      Statement St = conexao.createStatement();
		  ResultSet Rs = St.executeQuery(sql);
		  
		  modelo.setNumRows(0);
		  
		  String dataaux;
		  
		  while(Rs.next())
		  {  
			  dataaux = transferePraData(Rs.getString("Datanasc"));
			  modelo.addRow(new Object[]{ Rs.getString("RM"), Rs.getString("Nome"), dataaux, Rs.getString("RG"), Rs.getString("Telefone"), Rs.getString("Endereco"), Rs.getString("Datapagamento")});
		  } 
		  
		  St.close();
	      Rs.close();
		  conexao.close();
		   
		} catch (SQLException e) {
			mensagemDeErro(e);
		}
	      
	      
	}
	
	
	
	public void pesquisarAluno(String pesquisa, DefaultTableModel modelo, String tipopesquisa){
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			mensagemDeErro(e);
		}
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = "SELECT * FROM `alunos` WHERE " + tipopesquisa + " like '" + pesquisa + "%'";
	      
	      Connection conexao;
		try {
			conexao = DriverManager.getConnection(url, "root", "");
			
			 Statement St = conexao.createStatement();
		     ResultSet Rs = St.executeQuery(sql);
		     
		     modelo.setNumRows(0);
			  
		     String dataaux;
		     
			  while(Rs.next())
			  {  
				  dataaux = transferePraData(Rs.getString("Datanasc"));
				  modelo.addRow(new Object[]{ Rs.getString("RM"), Rs.getString("Nome"), dataaux, Rs.getString("RG"), Rs.getString("Telefone"), Rs.getString("Endereco"), Rs.getString("Datapagamento")});
			  }
			
			   St.close();
		       Rs.close();
			   conexao.close();
				
		}
		catch (SQLException e) {
			mensagemDeErro(e);
		}
		
		
	}
	
	public void matricularAluno(int RM, int turma, TelaMatricula telaMatricula) {
		
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				JOptionPane.showMessageDialog(null, "Erro ao encontrar o driver MySQL!\nErro:" + e, "Falha na conex�o!", JOptionPane.ERROR_MESSAGE);
			}
	
			 String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
		         
			 String sql = "INSERT INTO `u157866330_kanri`.`registro` (`Cod`, `Turma`, `Rm`) VALUES (NULL, '" + turma + "', '" + RM + "'); ";
			
				
			Connection conexao;  
			try {
				
				conexao = DriverManager.getConnection(url, "root", "");	      
			      
			      JOptionPane.showMessageDialog(null, "Aluno Matriculado!", "Sucesso", JOptionPane.PLAIN_MESSAGE);
			      telaMatricula.dispose();
				
			 Statement St = conexao.createStatement();
		     St.executeUpdate(sql);
		     
		     St.close();
			 conexao.close();
				
				
			} catch (SQLException e) {
				mensagemDeErro(e);
				}
		     
		}
	
	public void removerMatricula(int RM, int turma) {
		
		try
		{
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				mensagemDeErro(e);
				}

			String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	        
			Connection conexao;
			try {
				
				conexao = (Connection) DriverManager.getConnection(url, "root", "");
			
				Statement St = (Statement) conexao.createStatement();
		        St.executeUpdate("DELETE FROM `u157866330_kanri`.`registro` WHERE `registro`.`Rm` = " + RM + " && `registro`.`Turma` = " + turma + ";");
		        						
		        JOptionPane.showMessageDialog(null, "Aluno removido!", "Sucesso", JOptionPane.PLAIN_MESSAGE);
		        
		       
		        St.close();
				conexao.close();
						     
			} catch (SQLException e) {
				mensagemDeErro(e);
			}

		}
		catch(NumberFormatException e)		{
			JOptionPane.showMessageDialog(null, "Selecione algo!", "Aten��o!", JOptionPane.ERROR_MESSAGE);
		}	
		catch(NullPointerException e)		{
			JOptionPane.showMessageDialog(null, "Selecione algo!", "Aten��o!", JOptionPane.ERROR_MESSAGE);
		}	
	}
	
	
	// Turmas do aluno
	public void atualizarTurmas2(DefaultTableModel modelo, int RM) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			mensagemDeErro(e);
			}
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = "SELECT r.Turma, t.* FROM registro r INNER JOIN turma t on t.Cod = r.Turma WHERE r.Rm = " + RM + " ";
	
	      Connection conexao;
		try {
			
		  conexao = DriverManager.getConnection(url, "root", "");
				      
	      Statement St = conexao.createStatement();
		  ResultSet Rs = St.executeQuery(sql);
		  
		  modelo.setNumRows(0);
		  
		  while(Rs.next())
		  {  
			  modelo.addRow(new Object[]{ Rs.getInt("Turma"), Rs.getString("Disciplina"), Rs.getInt("Semestre")});
		  } 
		  
		  St.close();
		  Rs.close();
		  conexao.close();
			
		} catch (SQLException e) {
			mensagemDeErro(e);
		}
		
	}
		
	
	// Tela Men��es X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X
	
	public void cadastrarMencao(float teorica, float pratica, int turma, int RM)
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			mensagemDeErro(e);
		}
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = null;
	      
	      if(teorica == 0)
	      {
	    	  System.out.println("PRATICA BIRLL");
	    	   sql = "UPDATE `u157866330_kanri`.`notas` SET `Pratica` = '" + pratica + "' WHERE `notas`.`Aluno` = '" + RM + "' && `notas`.`Turma` = '" + turma + "'";
	    	   
	      }
	      else{
	    	  if(pratica == 0)
	    	  {
		    	  System.out.println("TEORICA BIRLL");
	    		  System.out.println();
	    		   sql = "UPDATE `u157866330_kanri`.`notas` SET `Teorica` = '" + teorica + "' WHERE `notas`.`Aluno` = '" + RM + "' && `notas`.`Turma` = '" + turma + "'";
	    	  }
	      }
	      Connection conexao;
	      
		try {
			conexao = DriverManager.getConnection(url, "root", ""); 
			
			Statement St = conexao.createStatement();
			int res = St.executeUpdate(sql);
	      
			if(res == 1)
			{
				JOptionPane.showMessageDialog(null, "Men��o cadastrada.", "Sucesso", JOptionPane.PLAIN_MESSAGE);
			}
			
	        St.close();
			conexao.close();
		  
		} catch (SQLException e) {
			e.printStackTrace();
			mensagemDeErro(e);
			}
	    
	     
	}
	
	
	public void atualizarMencao(DefaultTableModel modelo, int turma){
	
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			mensagemDeErro(e);
		}
		
		String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
		
		String sql = "SELECT r.RM, a.Nome, n.Teorica, n.Pratica, r.Turma, t.Disciplina, t.Semestre FROM registro r INNER JOIN turma t on t.Cod = r.Turma INNER JOIN alunos a on r.Rm = a.Rm INNER JOIN notas n on a.Rm = n.Aluno where r.Turma = " + turma + " order by a.Nome";
 
		Connection conexao;	
		try {
			
			conexao = DriverManager.getConnection(url, "root", "");
			
			Statement St = conexao.createStatement();
			ResultSet Rs = St.executeQuery(sql);
			modelo.setNumRows(0);
			
			while(Rs.next())
			{
				Mencao mencao = new Mencao();
				mencao.setRM(Rs.getInt("RM"));
				mencao.setNome(Rs.getNString("Nome"));
				mencao.setTeorica(Rs.getFloat("Teorica"));
				mencao.setPratica(Rs.getFloat("Pratica"));
				mencao.setTurma(Rs.getInt("Turma"));
				mencao.setDisciplina(Rs.getInt("Disciplina"));
				mencao.setSemestre(Rs.getInt("Semestre"));
				
				modelo.addRow(new String[]{
						
						String.valueOf(mencao.getRM()),
						mencao.getNome(),
						String.valueOf(mencao.getTeorica()),
						String.valueOf(mencao.getPratica()),
						String.valueOf(mencao.getTurma()),
						String.valueOf(mencao.getDisciplina()),
						String.valueOf(mencao.getSemestre())
							
				});
			}
			
			St.close();
			Rs.close();
			conexao.close();
			
		} catch (SQLException e) {
			mensagemDeErro(e);
		}
		
	}

	
	// Tela Turmas X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X
	
	// Todas as turmas na JComboBox [List<Turma> (foreach)]
	public List<Turma> atualizarTurmas(List<Turma> listadeturmas) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			mensagemDeErro(e);
		}
		
		String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
		
		String sql = "SELECT * FROM turma";
		
		Connection conexao;	
		try {
			
			conexao = DriverManager.getConnection(url, "root", "");
			
			Statement St = conexao.createStatement();
			ResultSet Rs = St.executeQuery(sql);
						
			
			while(Rs.next())
			{
				Turma turma = new Turma();
				turma.setCod(Rs.getInt("Cod"));			
				listadeturmas.add(turma);
				
			}
			
			St.close();
			Rs.close();
			conexao.close();
			
		} catch (SQLException e) {
			mensagemDeErro(e);
		}
	
		return listadeturmas;
		
	}	
	
	// Tabela da tela Turmas
	public DefaultTableModel atualizarTurmas3(DefaultTableModel modelo) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			mensagemDeErro(e);
		}
		
		String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
		
		String sql = "SELECT turma.*, disciplina.Nome as NomeD FROM turma inner join disciplina on disciplina.Cod = turma.disciplina order by turma.Cod";
		
		Connection conexao;	
		try {
			
			conexao = DriverManager.getConnection(url, "root", "");
			
			Statement St = conexao.createStatement();
			ResultSet Rs = St.executeQuery(sql);
						
			modelo.setNumRows(0);
			
			while(Rs.next())
			{
				Turma turma = new Turma();
				turma.setCod(Rs.getInt("Cod"));
				turma.setSala(Rs.getInt("Sala"));
				
				String dataaux = Rs.getDate("Data").toString();
				dataaux = transferePraData(dataaux);
				//turma.setData(Rs.getDate("Data"));
				turma.setCapacidade(Rs.getInt("Capacidade"));
				turma.setPeriodo(Rs.getString("Periodo"));
				turma.setHorarioIni(Rs.getTime("Horarioini"));
				turma.setHorarioFin(Rs.getTime("Horariofin"));
				turma.setDuracao(Rs.getInt("Duracao"));
				turma.setSemestre(Rs.getInt("Semestre"));
				turma.setDisciplina(Rs.getString("NomeD"));	
				
				modelo.addRow(new String[]{ String.valueOf(turma.getCod()), String.valueOf(turma.getDisciplina()), String.valueOf(turma.getSemestre()), String.valueOf(turma.getPeriodo()), String.valueOf(turma.getHorarioIni()),  String.valueOf(turma.getHorarioFin()), String.valueOf(turma.getSala()), String.valueOf(turma.getCapacidade()), dataaux, String.valueOf(turma.getDuracao())});
			
			}
			
			
		} catch (SQLException e) {
			mensagemDeErro(e);
		}

		return modelo;
		
	}
		
		
	public void cadastrarTurma(Turma turma, TelaTurmasCadastrar telaTurmasCadastrar, DefaultTableModel modelo) {
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				mensagemDeErro(e);
			}
			
			String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
						
			Connection conexao;	
			try {
				
				String sqlDisciplinas = "SELECT * FROM disciplina WHERE Nome = '" + turma.getDisciplina() + "' ";
				
				conexao = DriverManager.getConnection(url, "root", "");
				
				Statement St = conexao.createStatement(); 
				
				ResultSet Rs = St.executeQuery(sqlDisciplinas);
				
				
				Rs.first();
						
				turma.setDisciplina(String.valueOf((Rs.getInt("Cod"))));
			
				String sql = "INSERT INTO `u157866330_kanri`.`turma` (`Cod`, `Sala`, `Data`, `Capacidade`, `Periodo`, `Horarioini`, `Horariofin`, `Duracao`, `Semestre`, `Disciplina`) VALUES (NULL, '" + turma.getSala() + "', '" + turma.getData() + "', '" + turma.getCapacidade() + "', '" + turma.getPeriodo() + "', '" + turma.getHorarioIni() + "', '" + turma.getHorarioFin() + "', '" + turma.getDuracao() + "', '" + turma.getSemestre() + "', '" + turma.getDisciplina() + "');";
				
				int res = St.executeUpdate(sql);
				
				if(res == 1)
				{
					JOptionPane.showMessageDialog(telaTurmasCadastrar, "Turma cadastrada!", "Sucesso", JOptionPane.PLAIN_MESSAGE);
				}
				atualizarTurmas3(modelo);
				telaTurmasCadastrar.dispose();
				
				
				St.close();
				Rs.close();
				conexao.close();
	
		}catch(SQLException e){
			mensagemDeErro(e);
			e.printStackTrace();
		}


		}
	
	public void alterarTurma(Turma turma, DefaultTableModel modelo, TelaTurmasAlterar telaTurmasAlterar)
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			mensagemDeErro(e);
		}
		
		String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
		
		String sqlDisciplinas = "SELECT * FROM disciplina WHERE Nome = '" + turma.getDisciplina() + "' ";
		 
		Connection conexao;	
		try {
			
			conexao = DriverManager.getConnection(url, "root", "");
			
			Statement St = conexao.createStatement();
		
			ResultSet Rs = St.executeQuery(sqlDisciplinas);
			
			Rs.first();
					
			turma.setDisciplina(String.valueOf((Rs.getInt("Cod"))));

			
			String sql = "UPDATE `u157866330_kanri`.`turma` SET `Sala` = '" + turma.getSala() + "', `Data` = '" + turma.getData() + "', `Capacidade` = '" + turma.getCapacidade() + "', `Periodo` = '" + turma.getPeriodo() + "', `Horarioini` = '" + turma.getHorarioIni() + "', `Horariofin` = '" + turma.getHorarioFin() + "', `Duracao` = '" + turma.getDuracao()+ "', `Semestre` = '" + turma.getSemestre() + "', `Disciplina` = '" + turma.getDisciplina() + "' WHERE `turma`.`Cod` = '" + turma.getCod() + "'; ";
			
			St.executeUpdate(sql);			
			JOptionPane.showMessageDialog(telaTurmasAlterar, "Turma alterada!", "Sucesso", JOptionPane.PLAIN_MESSAGE);
			atualizarTurmas3(modelo);
			telaTurmasAlterar.dispose();
			
			
			St.close();
			conexao.close();
			
		} catch (SQLException e) {
			mensagemDeErro(e);
		}
	}
	
	
	public void excluirTurma(Turma turma, DefaultTableModel modelo) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			mensagemDeErro(e);
		}
		
		String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
		
		String sql = "DELETE FROM `u157866330_kanri`.`turma` WHERE `turma`.`Cod` = " + turma.getCod();
		
		Connection conexao;	
		try {
			
			conexao = DriverManager.getConnection(url, "root", "");
			
			Statement St = conexao.createStatement();
			St.executeUpdate(sql);			
			JOptionPane.showMessageDialog(null, "Turma exclu�da!", "Sucesso", JOptionPane.PLAIN_MESSAGE);
			atualizarTurmas3(modelo);
			
			St.close();
			conexao.close();
			
		} catch (SQLException e) {
			mensagemDeErro(e);
		}
		
	}
		
	
	public void atualizaDisciplinas(List<Disciplina> listaDisciplinas) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			mensagemDeErro(e);
		}
		
		String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
		
		String sql = "SELECT * FROM disciplina";
		
		Connection conexao;	
		try {
			
			conexao = DriverManager.getConnection(url, "root", "");
			
			Statement St = conexao.createStatement();
			ResultSet Rs = St.executeQuery(sql);
						
			
			while(Rs.next())
			{
				Disciplina disciplina = new Disciplina();
				disciplina.setCod(Rs.getInt("Cod"));
				disciplina.setNome(Rs.getString("Nome"));
				listaDisciplinas.add(disciplina);
			}
			
			St.close();
			Rs.close();
			conexao.close();
			
		} catch (SQLException e) {
			mensagemDeErro(e);
		}
			
		}
		
	
	
	
	// Tela Pagamentos	X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X-X
	
	public void atualizarPg1(DefaultTableModel dtm) throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = "SELECT mesesatra.rm, alunos.Nome, mesesatra.ma FROM mesesatra inner join alunos on mesesatra.rm = alunos.rm where mesesatra.ma > 1";
	
	      Connection conexao = DriverManager.getConnection(url, "root", "");
	      
	      System.out.println("Conectou!");
	      
	      Statement stVizualizar = conexao.createStatement();
		  ResultSet rsAtualizar = stVizualizar.executeQuery(sql);
		  dtm.setNumRows(0);
		  
		  while(rsAtualizar.next())
		  {  
			 
			 dtm.addRow(new Object[]{ rsAtualizar.getString("RM"), rsAtualizar.getString("Nome"), rsAtualizar.getString("ma")});
		
		  }
		
	}


	public void atualizarPg2(DefaultTableModel dtm2) throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = "SELECT mesesatra.rm , alunos.nome , alunos.datapagamento FROM `mesesatra` inner join alunos on mesesatra.rm = alunos.rm WHERE mesesatra.ma = 1";
	
	      Connection conexao = DriverManager.getConnection(url, "root", "");
	      
	      System.out.println("Conectou!");
	      
	      Statement stVizualizar = conexao.createStatement();
		  ResultSet rsAtualizar = stVizualizar.executeQuery(sql);
		  dtm2.setNumRows(0);
		  
		  while(rsAtualizar.next())
		  {  
			  dtm2.addRow(new Object[]{ rsAtualizar.getString("RM"), rsAtualizar.getString("Nome"), rsAtualizar.getString("Datapagamento")});
		  }
		
	}


	public void atualizarPag(DefaultTableModel dtm) throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = "SELECT mesesatra.rm, alunos.nome,registro.turma FROM registro inner join alunos on registro.rm = alunos.rm inner join mesesatra on mesesatra.rm = alunos.rm where mesesatra.ma = 0";
	
	      Connection conexao = DriverManager.getConnection(url, "root", "");
	      
	      System.out.println("Conectou!");
	      
	      Statement stVizualizar = conexao.createStatement();
		  ResultSet rsAtualizar = stVizualizar.executeQuery(sql);
		  dtm.setNumRows(0);
		  
		  while(rsAtualizar.next())
		  {  
			  dtm.addRow(new Object[]{ rsAtualizar.getString("RM"), rsAtualizar.getString("Nome"), rsAtualizar.getString("Turma")});
			  
		  }
	}


	public void desatrasarMes(String rm) throws SQLException, ClassNotFoundException {
		
		int Rm = Integer.parseInt(rm);
		LocalDate ldata = mesesEmAtra(Rm);
		Date data = java.sql.Date.valueOf(ldata);
	
		
			Class.forName("com.mysql.jdbc.Driver");
	
		
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
		String sql = "UPDATE `u157866330_kanri`.`mesesatra` SET `data` = '"+data+"' WHERE `mesesatra`.`Rm` = "+Rm+";";
	      
	      Connection conexao = DriverManager.getConnection(url, "root", "");
	
	     Statement stAlterar = conexao.createStatement();
	     stAlterar.executeUpdate(sql);
	     
	     stAlterar.close();
	     conexao.close();
	     mesAtra();
	
	}

	public LocalDate mesesEmAtra(int rm) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		Date dat = new Date();
		LocalDate data = null;
		int ma;
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = "SELECT data, ma from mesesatra where Rm = " + rm + ";" ;
	
	      Connection conexao = DriverManager.getConnection(url, "root", "");
	      
	      
	      
	      Statement stVizualizar = conexao.createStatement();
		  ResultSet rsAtualizar = stVizualizar.executeQuery(sql);
		  
		  
		  while(rsAtualizar.next())
		  {  
			  ma = Integer.parseInt(rsAtualizar.getString("ma"));
			  
			  if(ma >= 1){
				  dat = rsAtualizar.getDate("data");
				   
				   ZoneId defaultZoneId = ZoneId.systemDefault();
			        Instant instant = Instant.ofEpochMilli(dat.getTime());
			        data = instant.atZone(defaultZoneId).toLocalDate();
			        data = data.plusMonths(1);
				return data;
				  }else{
					  dat = rsAtualizar.getDate("data");
					   
					   ZoneId defaultZoneId = ZoneId.systemDefault();
				        Instant instant = dat.toInstant();
				        data = instant.atZone(defaultZoneId).toLocalDate();
					  
		  }
		  
		
			  
		  }
		return data;
	
		
		
	}


	
	public void mesAtra() throws ClassNotFoundException, SQLException{
		Date dataAtra = null;
		String RM;
		Class.forName("com.mysql.jdbc.Driver");
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = "SELECT Rm, data FROM mesesatra";
	
	      Connection conexao = DriverManager.getConnection(url, "root", "");
	      
	      System.out.println("Conectou!");
	      
	      Statement stVizualizar = conexao.createStatement();
		  ResultSet rsAtualizar = stVizualizar.executeQuery(sql);
		 
		  
		  while(rsAtualizar.next())
		  {  
			  Date dataFim = new Date();
			  dataAtra = rsAtualizar.getDate("data");
			  RM = rsAtualizar.getString("Rm");
			  final double MES_EM_MILISEGUNDOS = 30.0 * 24.0 * 60.0 * 60.0 * 1000.0;
				//final double MES_EM_MILISEGUNDOS = 2592000000.0;
				int numeroDeMeses = (int)((dataFim.getTime() - dataAtra.getTime())/MES_EM_MILISEGUNDOS);
				
			 alteraMA(RM,numeroDeMeses); 
			 
			  
		  }
		
	}

	private void alteraMA(String rM ,int numeroDeMeses) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		
	      String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
	      
	      String sql = "UPDATE `u157866330_kanri`.`mesesatra` SET `ma` = '"+numeroDeMeses+"' WHERE `mesesatra`.`Rm` = "+rM+";";
	      
	      Connection conexao = DriverManager.getConnection(url, "root", "");
	
	     Statement stAlterar = conexao.createStatement();
	     stAlterar.executeUpdate(sql);
	     
	     stAlterar.close();
	     conexao.close();
		
	}


	
		

	// Interno
	
	public boolean senha() {
		return true;	
	}
	
	private String transferePraData(String data)
	{
		
		String dataaux = data.charAt(8) + "" + data.charAt(9) + "" + data.charAt(7) + "" + data.charAt(5) + "" + data.charAt(6) + "" + data.charAt(4) + "" + data.charAt(0) + "" + data.charAt(1) + "" + data.charAt(2) + "" + data.charAt(3); 
		
		return dataaux;
	}
	
	private void mensagemDeErro(Object erro)
		{
			JOptionPane.showMessageDialog(null, "N�o foi poss�vel executar a opera��o! \nErro:" + erro, "Erro", JOptionPane.ERROR_MESSAGE);
		}


}
