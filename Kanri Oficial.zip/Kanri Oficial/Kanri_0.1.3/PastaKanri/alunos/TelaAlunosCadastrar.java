package alunos;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;


import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;




import dao.ClasseComandos;

import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;

@SuppressWarnings("serial")
public class TelaAlunosCadastrar extends JFrame {
	
	private JPanel contentPane;
	private JPanel pCampos;
	
	private String foto;
	
	public JTextField txtNome;
	
	private JTextField txtRG;
	private MaskFormatter formatoRG;
	
	private JTextField txtTelefone;
	private MaskFormatter formatoTelefone;
 
	private JTextField txtEndereco;
	
	private JTextField txtDataNascimento;
	private MaskFormatter formatoDataNasc;
	private JTextField txtDatapag;
	private JTextField txtSenha;
	
	private String erros = "Campos irregulares:\n";
	
	public TelaAlunosCadastrar(DefaultTableModel dtm){
		
		setResizable(false);
		setTitle("Kanri - Aluno");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocation(700, 200);
		setBounds(100, 100, 360, 510);
		setLocationRelativeTo(null);
		
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		pCampos = new JPanel();
		pCampos.setBackground(Color.DARK_GRAY);
		pCampos.setBounds(0, 0, 354, 482);
		contentPane.add(pCampos);
		pCampos.setVisible(true);
		pCampos.setLayout(null);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(10, 11, 46, 14);
		lblNome.setForeground(Color.WHITE);
		lblNome.setFont(new Font("Gulim", Font.PLAIN, 15));
		pCampos.add(lblNome);
		
		txtNome = new JTextField();
		txtNome.setBounds(10, 35, 334, 20);
		txtNome.setBackground(Color.WHITE);
		txtNome.setForeground(new Color(102, 153, 102));
		txtNome.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		pCampos.add(txtNome);
		txtNome.setColumns(10);
		
		
		
		JLabel lblRG = new JLabel("RG:");
		lblRG.setBounds(10, 67, 46, 14);
		lblRG.setForeground(Color.WHITE);
		lblRG.setFont(new Font("Gulim", Font.PLAIN, 15));
		pCampos.add(lblRG);	
		
		try {
			formatoRG = new MaskFormatter("##.###.###-#");
		} catch (ParseException e1) {
			System.out.println("JFTF com erro!");
			e1.printStackTrace();
		}
		txtRG = new JFormattedTextField(formatoRG);
		txtRG.setBounds(10, 90, 190, 20);
		txtRG.setBackground(Color.WHITE);
		txtRG.setForeground(new Color(102, 153, 102));
		txtRG.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		pCampos.add(txtRG);
		txtRG.setColumns(10);
		
		JLabel lblTelefone = new JLabel("Telefone:");
		lblTelefone.setBounds(10, 122, 70, 14);
		lblTelefone.setForeground(Color.WHITE);
		lblTelefone.setFont(new Font("Gulim", Font.PLAIN, 15));
		pCampos.add(lblTelefone);
		
		
		txtTelefone = new JFormattedTextField(formatoTelefone);
		txtTelefone.setBounds(10, 145, 135, 20);
		txtTelefone.setBackground(Color.WHITE);
		txtTelefone.setForeground(new Color(102, 153, 102));
		txtTelefone.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		txtTelefone.setColumns(10);
		pCampos.add(txtTelefone);
		
		JLabel lblEndereco = new JLabel("Endere\u00E7o:");
		lblEndereco.setBounds(10, 176, 80, 14);
		lblEndereco.setForeground(Color.WHITE);
		lblEndereco.setFont(new Font("Gulim", Font.PLAIN, 15));
		pCampos.add(lblEndereco);
		
		txtEndereco = new JTextField();
		txtEndereco.setBounds(10, 200, 334, 20);
		txtEndereco.setBackground(Color.WHITE);
		txtEndereco.setForeground(new Color(102, 153, 102));
		txtEndereco.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		txtEndereco.setColumns(10);
		pCampos.add(txtEndereco);
		
		JLabel lblDataNascimento = new JLabel("Data de nascimento:");
		lblDataNascimento.setBounds(10, 231, 160, 14);
		lblDataNascimento.setForeground(Color.WHITE);
		lblDataNascimento.setFont(new Font("Gulim", Font.PLAIN, 15));
		pCampos.add(lblDataNascimento);
		
		try {
			formatoDataNasc = new MaskFormatter("##-##-####");
		} catch (ParseException e1) {
			System.out.println("JFTF com erro!");
			e1.printStackTrace();
		}
		txtDataNascimento = new JFormattedTextField(formatoDataNasc);
		txtDataNascimento.setBounds(10, 256, 120, 20);
		txtDataNascimento.setBackground(Color.WHITE);
		txtDataNascimento.setForeground(new Color(102, 153, 102));
		txtDataNascimento.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		txtDataNascimento.setColumns(10);
		pCampos.add(txtDataNascimento);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(10, 407, 202, 66);
		btnSalvar.setForeground(Color.WHITE);
		btnSalvar.setFont(new Font("Gulim", Font.BOLD, 15));
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent salvar) {				
					
					telaCadastrar(txtNome.getText(), txtRG.getText(), txtEndereco.getText(), txtDataNascimento.getText(), txtTelefone.getText(), foto, txtDatapag.getText(), md5(txtSenha.getText()));				
					ClasseComandos cmdAtualizar = new ClasseComandos();
					cmdAtualizar.atualizarAluno(dtm);
					
					
			
			}});
		
		JLabel lblDataDePagamento = new JLabel("Data de pagamento:");
		lblDataDePagamento.setBounds(10, 288, 160, 16);
		lblDataDePagamento.setForeground(Color.WHITE);
		lblDataDePagamento.setFont(new Font("Gulim", Font.PLAIN, 15));
		pCampos.add(lblDataDePagamento);
		
		txtDatapag = new JTextField();
		txtDatapag.setForeground(new Color(102, 153, 102));
		txtDatapag.setBounds(10, 316, 135, 20);
		pCampos.add(txtDatapag);
		txtDatapag.setColumns(10);
		
		JLabel lblSenhaDoWebsite = new JLabel("Senha do website:");
		lblSenhaDoWebsite.setForeground(Color.WHITE);
		lblSenhaDoWebsite.setFont(new Font("Gulim", Font.PLAIN, 15));
		lblSenhaDoWebsite.setBounds(10, 348, 160, 16);
		pCampos.add(lblSenhaDoWebsite);
		
		txtSenha = new JPasswordField();
		txtSenha.setForeground(new Color(102, 153, 102));
		txtSenha.setBounds(10, 376, 120, 20);
		pCampos.add(txtSenha);
		txtSenha.setColumns(10);
		
		
		btnSalvar.setBackground(new Color(102, 255, 51));
		pCampos.add(btnSalvar);
		
		JButton btnSair = new JButton("Cancelar");
		btnSair.setBounds(222, 407, 120, 66);
		btnSair.setForeground(Color.WHITE);
		btnSair.setFont(new Font("Gulim", Font.BOLD, 15));
		btnSair.setBackground(new Color(102, 255, 51));
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent clickSair) {
				

				int res = JOptionPane.showConfirmDialog(null, "Deseja mesmo cancelar o cadastro do aluno?", "Confirma��o", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
			
				if(res == 0)
				{
					limpaCampos();
				}
			}
				
		});
		pCampos.add(btnSair);
		
		JButton btnFoto = new JButton("Foto");
		btnFoto.setBounds(142, 376, 202, 20);
		btnFoto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				foto = new Escolher().buscar();
			}
		});
		btnFoto.setForeground(Color.WHITE);
		btnFoto.setFont(new Font("Gulim", Font.BOLD, 15));
		btnFoto.setBackground(new Color(102, 153, 102));
		pCampos.add(btnFoto);
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent evt) {
		
				 JOptionPane.showMessageDialog(null, "As informa��es do aluno a ser cadastrado foram perdidas.", "Confirma��o", JOptionPane.PLAIN_MESSAGE);
				limpaCampos();
			
			}});
		
	}
	
	public void telaCadastrar(String nome, String RG, String endereco, String datanasc, String telefone, String foto, String datapag, String senha)	{
		
		
		int resp = JOptionPane.showConfirmDialog(null, "Deseja mesmo salvar esse aluno?", "Confirma��o",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		
		if(resp == 0){
			
			if(!txtNome.getText().equals("") && !txtRG.getText().equals("") && !txtTelefone.getText().equals("") &&  !txtEndereco.getText().equals("") && !txtDataNascimento.getText().equals(""))
			{

				
				if(verificaRestricoes() == true){
					
				ClasseComandos cmdCadastrar = new ClasseComandos();
				
				datanasc = transeferePraData(datanasc);
				
				cmdCadastrar.cadastrarAluno(nome, RG, endereco, datanasc, telefone, foto, datapag, senha);
				
				txtNome.setText("");
				txtRG.setText("");
				txtTelefone.setText("");
				txtEndereco.setText("");
				txtDataNascimento.setText("");
				txtSenha.setText("");
				txtDatapag.setText("");
				foto = "";
				dispose();
				
				}
				else{	
					JOptionPane.showMessageDialog(this, erros, "Erro no cadastro", JOptionPane.ERROR_MESSAGE);
					erros = "Campos irregulares:\n";
				}
				
				}
			else
			{
				JOptionPane.showMessageDialog(null, "Preencha todos os campos!", "Aten��o!", JOptionPane.ERROR_MESSAGE);
			}
		}
	}//Paretes�s do m�todo

	private void limpaCampos()
	{
	txtNome.setText("");
	txtRG.setText("");
	txtTelefone.setText("");
	txtEndereco.setText("");
	txtDataNascimento.setText("");
	txtDatapag.setText("");
	dispose();
	}
	
	private String transeferePraData(String data)
	{
		
		String dataaux = data.charAt(6) + "" + data.charAt(7) + "" + data.charAt(8) + "" + data.charAt(9) + "" + data.charAt(5) + "" + data.charAt(3) + "" + data.charAt(4) + "" + data.charAt(2) + "" + data.charAt(0) + "" + data.charAt(1); 
		
		return dataaux;
	}
	
	private boolean verificaRestricoes()
	{
		
		boolean nesseIf = true;
		
		if(txtNome.getText().length() < 40)
		{
			
		}else{
			txtNome.setBackground(new Color(255, 0, 0));
			erros += "Nome\n";
			nesseIf = false;
			}
		
		if(txtTelefone.getText().length() < 16)
		{
		}else{
			txtTelefone.setBackground(new Color(255, 0, 0));
			erros += "Telefone\n";
			nesseIf = false;
			}
		
		if(txtEndereco.getText().length() < 30)
		{
		}else{
			txtEndereco.setBackground(new Color(255, 0, 0));
			erros += "Endereco\n";
			nesseIf = false;
			}		
	
		System.out.println(nesseIf);
		
		return nesseIf;
		
	}
	
	
	
	public static String md5(String senha){
		String sen = "";
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		BigInteger hash = new BigInteger(1, md.digest(senha.getBytes()));
		sen = hash.toString(16);			
		return sen;
	}
	
}
	

		
