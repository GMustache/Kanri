package principal;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.JButton;

import dao.ClasseComandos;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;


@SuppressWarnings("serial")
public class TelaLogin extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsuario;
	private JTextField txtSenha;

	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
					TelaLogin frame = new TelaLogin();
					frame.setVisible(true);
	}

	public TelaLogin() {
		
		setTitle("Kanri - Login");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsuario = new JLabel("Usu\u00E1rio:");
		lblUsuario.setForeground(Color.WHITE);
		lblUsuario.setFont(new Font("Gulim", Font.PLAIN, 40));
		lblUsuario.setBounds(10, 11, 474, 60);
		contentPane.add(lblUsuario);
		
		txtUsuario = new JTextField();
		txtUsuario.setBackground(Color.WHITE);
		txtUsuario.setForeground(new Color(102, 255, 102));
		txtUsuario.setFont(new Font("Gulim", Font.PLAIN, 35));
		txtUsuario.setBounds(10, 82, 474, 40);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setForeground(Color.WHITE);
		lblSenha.setFont(new Font("Gulim", Font.PLAIN, 40));
		lblSenha.setBounds(10, 133, 474, 60);
		contentPane.add(lblSenha);
		
		txtSenha = new JPasswordField();
		txtSenha.setBackground(Color.WHITE);
		txtSenha.setForeground(new Color(102, 255, 102));
		txtSenha.setFont(new Font("Showcard Gothic", Font.BOLD, 35));
		txtSenha.setColumns(10);
		txtSenha.setBounds(10, 204, 474, 40);
		contentPane.add(txtSenha);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setFont(new Font("Gulim", Font.BOLD, 35));
		btnLogin.setForeground(Color.WHITE);
		btnLogin.setBackground(new Color(102, 255, 51));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent cliqueAdm) {
				
				try {
					TelaLogar(txtUsuario.getText(), txtSenha.getText());
				}
				catch (ClassNotFoundException | SQLException | NumberFormatException e) {

					e.printStackTrace();
				}
				
			}
		});
		getRootPane().setDefaultButton(btnLogin);
		btnLogin.setBounds(150, 310, 195, 50);
		contentPane.add(btnLogin);
	}
	
	
	// AQUI TEMOS DROGAS ILICITAS
	
	private void TelaLogar(String usuario, String senha) throws ClassNotFoundException, SQLException
	{
		
		senha = senha.toLowerCase();
		
		if(usuario.equals("") || senha.equals(""))
		{
			JOptionPane.showMessageDialog(this, "Preencha os campos!", "Falha no login!", JOptionPane.ERROR_MESSAGE);
		}
		else
		{
		ClasseComandos comandoLogar = new ClasseComandos();
		comandoLogar.logar(usuario, senha, this, txtUsuario, txtSenha);
		}
	}
	
}
