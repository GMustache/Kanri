package pagamentos;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.table.TableModel;
import javax.xml.crypto.Data;

import bean.Turma;
import dao.ClasseComandos;
import alunos.TelaAlunosCadastrar;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

@SuppressWarnings({ "serial", "unused" })
public class TelaPagamento extends JFrame {

	TelaAlunosCadastrar telaAlunosCadastrar;
	
	private JPanel contentPane;
	private JTable table;
	private String location;
	private JTable table_1;
	private DefaultTableModel dtm;
	private DefaultTableModel dtm2;

	private List<Turma> listadeturmas = new ArrayList<Turma>();
	private int turma = 0;

	public void setLocation(String Location) {
		location = Location;
	}
	
	public TelaPagamento() throws ClassNotFoundException, SQLException {
		
		data();
		setResizable(false);
		setTitle("Kanri - Gerenciar Alunos");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 794, 580);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel pTable = new JPanel();
		pTable.setBackground(new Color(102, 255, 102));
		pTable.setBounds(12, 27, 770, 371);
		contentPane.add(pTable);
		pTable.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

			table_1.getSelectionModel().clearSelection();
			
				
			}
		});
		scrollPane.setBounds(10, 11, 370, 352);
		pTable.add(scrollPane);
		
		dtm = new DefaultTableModel(new Object[][] {{
			
		}},
			new String[] {
					"RM","Nome","MA"
		});
		

		table = new JTable(dtm);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				table_1.getSelectionModel().clearSelection();
			}
		});
		table.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		table.setSelectionBackground(new Color(200, 200, 0));
		scrollPane.setViewportView(table);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				table.getSelectionModel().clearSelection();
			}
		});
		scrollPane_1.setBounds(390, 11, 370, 352);
		pTable.add(scrollPane_1);
		
         DefaultTableModel dtm2 = new DefaultTableModel(new Object[][] {{
			
		}},
			new String[] {
				"RM","Nome","DataPagamento"
		});
		
		table_1 = new JTable(dtm2);
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				table.getSelectionModel().clearSelection();;
			}
		});
		
		table_1.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		scrollPane_1.setViewportView(table_1);
		
		JPanel pCampos = new JPanel();
		pCampos.setForeground(Color.DARK_GRAY);
		pCampos.setBackground(Color.DARK_GRAY);
		pCampos.setBounds(12, 401, 770, 136);
		contentPane.add(pCampos);
		pCampos.setLayout(null);
		
		JButton btnCadastrar = new JButton("Executar Pagamentos");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arks) {
				
				senhaConfirmar();						
								
			}
		});
		btnCadastrar.setForeground(Color.WHITE);
		btnCadastrar.setFont(new Font("Gulim", Font.BOLD, 25));
		btnCadastrar.setBackground(new Color(102, 255, 102));
		btnCadastrar.setBounds(10, 40, 370, 50);
		pCampos.add(btnCadastrar);
		
		JButton btnExcluir = new JButton("Ver Pagos");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TelaPagos iu = new TelaPagos();
				iu.setVisible(true);
			}
		});
		btnExcluir.setForeground(Color.WHITE);
		btnExcluir.setFont(new Font("Gulim", Font.BOLD, 35));
		btnExcluir.setBackground(new Color(102, 255, 102));
		btnExcluir.setBounds(390, 40, 370, 50);
		pCampos.add(btnExcluir);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setForeground(Color.DARK_GRAY);
		menuBar.setBackground(Color.DARK_GRAY);
		menuBar.setBounds(0, 0, 788, 21);
		contentPane.add(menuBar);
		
	
		ClasseComandos cmdAtualizaTurmas = new ClasseComandos();
		cmdAtualizaTurmas.atualizarTurmas(listadeturmas);
		
		JComboBox<Integer> jcbTurmas = new JComboBox<Integer>();
		for(Turma turma : listadeturmas)
		{
				System.out.println(turma.getCod());
				jcbTurmas.addItem(turma.getCod());
		}
		turma = (int) jcbTurmas.getSelectedItem();
		menuBar.add(jcbTurmas);
		jcbTurmas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent escolheTurma) {
				
				turma = (int) jcbTurmas.getSelectedItem();
				telaAtualizarTabela(turma);
				 
			}
		});
		jcbTurmas.setForeground(new Color(102, 255, 51));
		jcbTurmas.setFont(new Font("Copperplate Gothic Light", Font.PLAIN, 15));
		jcbTurmas.setBackground(Color.GRAY);
		turma = (int) jcbTurmas.getSelectedItem();
		
			
		JMenuItem mnAtualizar = new JMenuItem("Atualizar");
		mnAtualizar.setFont(new Font("Copperplate Gothic Light", Font.PLAIN, 15));
		mnAtualizar.setForeground(Color.WHITE);
		mnAtualizar.setBackground(Color.DARK_GRAY);
		mnAtualizar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
		menuBar.add(mnAtualizar);
		mnAtualizar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent atualizarTelaAlunos) {
				
		ClasseComandos cmdAtualizar = new ClasseComandos();
		try {
			cmdAtualizar.atualizarPg1(dtm);
			cmdAtualizar.atualizarPg2(dtm2);
			cmdAtualizar.mesAtra();
		} catch (Exception e) {
			e.printStackTrace();
		}

			}
		});
		
		


	}
	
	
	// M�todos internos	
	
	protected void senhaConfirmar() {
		
		if(!(table.getSelectedRow() >=0)){
			if(!(table_1.getSelectedRow() >=0)){
				JOptionPane.showMessageDialog(null,"Selecione uma linha por favor");
				}
				else{
				TelaConfirmar oi;
				try {
					oi = new TelaConfirmar((String) dtm2.getValueAt(table_1.getSelectedRow(), 0));
					oi.setVisible(true);
				} catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				}
				
				}
		}
		else{
		TelaConfirmar oi;
		try {
			oi = new TelaConfirmar((String) dtm.getValueAt(table.getSelectedRow(), 0));
			oi.setVisible(true);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		}

	}

	private void telaAtualizarTabela(int turma)
	{
		ClasseComandos cmdAtualizar = new ClasseComandos();
		
		try {
			cmdAtualizar.atualizarPg1(dtm);
			cmdAtualizar.atualizarPg2(dtm2);
			cmdAtualizar.mesAtra();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void data() throws ClassNotFoundException, SQLException{
		ClasseComandos oi = new ClasseComandos();
		oi.mesAtra();
		
        

		
	}
}