package alunos;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;

import dao.ClasseComandos;

import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.ParseException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;

@SuppressWarnings("serial")
public class TelaAlunosAlterar extends JFrame {
	
	private JPanel contentPane;
	private JPanel pCampos;
	
	//private String foto;
	
	public JTextField txtNome;
	
	private JTextField txtRG;
	private MaskFormatter formatoCPF;
	
	private JTextField txtTelefone;
	private JTextField txtEndereco;
	private JTextField txtSenha;
	private JTextField txtDatapag;
	private JTextField txtDataNascimento;
	private MaskFormatter formatoDataNasc;
	
	private String RM;
	private String erros = "Campos irregulares:\n";
	
	public TelaAlunosAlterar(String nome, String RG, String endereco, String datanasc, String telefone, String RM, String datapag, DefaultTableModel dtm) {
		
		this.RM = RM;
		
		setResizable(false);
		setTitle("Kanri - Aluno");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocation(700, 200);
		setBounds(100, 100, 360, 510);
		setLocationRelativeTo(null);
		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(75, 0, 130));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		pCampos = new JPanel();
		pCampos.setBackground(Color.DARK_GRAY);
		pCampos.setBounds(0, 0, 354, 496);
		contentPane.add(pCampos);
		pCampos.setLayout(null);
		pCampos.setVisible(true);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setForeground(Color.WHITE);
		lblNome.setFont(new Font("Gulim", Font.PLAIN, 15));
		lblNome.setBounds(10, 11, 135, 14);
		pCampos.add(lblNome);
		
		txtNome = new JTextField(nome);
		txtNome.setForeground(new Color(102, 153, 102));
		txtNome.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		txtNome.setBounds(10, 35, 332, 20);
		pCampos.add(txtNome);
		txtNome.setColumns(10);
		
		
		
		JLabel lblRG = new JLabel("RG:");
		lblRG.setForeground(Color.WHITE);
		lblRG.setFont(new Font("Gulim", Font.PLAIN, 15));
		lblRG.setBounds(10, 67, 135, 14);
		pCampos.add(lblRG);	
		
		try {
			formatoCPF = new MaskFormatter("##.###.###-#");
		} catch (ParseException e1) {
			System.out.println("JFTF com erro!");
			e1.printStackTrace();
		}
		
		txtRG = new JFormattedTextField(formatoCPF);
		txtRG.setForeground(new Color(102, 153, 102));
		txtRG.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		txtRG.setBounds(10, 90, 190, 20);
		txtRG.setText(RG);
		pCampos.add(txtRG);
		txtRG.setColumns(10);
		
		JLabel lblTelefone = new JLabel("Telefone:");
		lblTelefone.setForeground(Color.WHITE);
		lblTelefone.setFont(new Font("Gulim", Font.PLAIN, 15));
		lblTelefone.setBounds(10, 122, 135, 14);
		pCampos.add(lblTelefone);

		txtTelefone = new JTextField();
		txtTelefone.setForeground(new Color(102, 153, 102));
		txtTelefone.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		txtTelefone.setColumns(10);
		txtTelefone.setBounds(10, 145, 135, 20);
		txtTelefone.setText(telefone);
		pCampos.add(txtTelefone);
		
		JLabel lblEndereco = new JLabel("Endere\u00E7o:");
		lblEndereco.setForeground(Color.WHITE);
		lblEndereco.setFont(new Font("Gulim", Font.PLAIN, 15));
		lblEndereco.setBounds(10, 176, 135, 14);
		pCampos.add(lblEndereco);
		
		txtEndereco = new JTextField(endereco);
		txtEndereco.setForeground(new Color(102, 153, 102));
		txtEndereco.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		txtEndereco.setColumns(10);
		txtEndereco.setBounds(10, 200, 332, 20);
		pCampos.add(txtEndereco);
		
		JLabel lblDataNascimento = new JLabel("Data de Nascimento:");
		lblDataNascimento.setForeground(Color.WHITE);
		lblDataNascimento.setFont(new Font("Gulim", Font.PLAIN, 15));
		lblDataNascimento.setBounds(10, 231, 180, 14);
		pCampos.add(lblDataNascimento);
		
		try {
			formatoDataNasc = new MaskFormatter("##-##-####");
		} catch (ParseException e1) {
			System.out.println("JFTF com erro!");
			e1.printStackTrace();
		}
		txtDataNascimento = new JFormattedTextField(formatoDataNasc);
		txtDataNascimento.setForeground(new Color(102, 153, 102));
		txtDataNascimento.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		txtDataNascimento.setColumns(10);
		txtDataNascimento.setBounds(10, 256, 120, 20);
		txtDataNascimento.setText(datanasc);
		pCampos.add(txtDataNascimento);
		
		JLabel lblDataDePagamento = new JLabel("Data de pagamento:");
		lblDataDePagamento.setForeground(Color.WHITE);
		lblDataDePagamento.setFont(new Font("Gulim", Font.PLAIN, 15));
		lblDataDePagamento.setBounds(10, 288, 180, 14);
		pCampos.add(lblDataDePagamento);
		
		txtDatapag = new JTextField();
		txtDatapag.setText(datapag);
		txtDatapag.setForeground(new Color(102, 153, 102));
		txtDatapag.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		txtDatapag.setColumns(10);
		txtDatapag.setBounds(10, 314, 135, 20);
		pCampos.add(txtDatapag);
		
		JLabel lblSenha = new JLabel("Senha do website:");
		lblSenha.setForeground(Color.WHITE);
		lblSenha.setFont(new Font("Gulim", Font.PLAIN, 15));
		lblSenha.setBounds(10, 346, 180, 14);
		pCampos.add(lblSenha);
		
		txtSenha = new JTextField();
		txtSenha.setText("Indispon�vel");
		txtSenha.setForeground(new Color(102, 153, 102));
		txtSenha.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
		txtSenha.setColumns(10);
		txtSenha.setBounds(10, 372, 120, 20);
		txtSenha.setEnabled(false);
		pCampos.add(txtSenha);
		

		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.setForeground(Color.WHITE);
		btnAlterar.setFont(new Font("Gulim", Font.BOLD, 15));
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent salvar) {

					telaAlterar(txtNome.getText(), txtRG.getText(), txtEndereco.getText(), txtDataNascimento.getText(), txtTelefone.getText(), RM, txtDatapag.getText());
					ClasseComandos cmdAtualizar = new ClasseComandos();
					cmdAtualizar.atualizarAluno(dtm);
			
			}});
		
		btnAlterar.setBackground(new Color(102, 255, 102));
		btnAlterar.setBounds(10, 404, 202, 67);
		pCampos.add(btnAlterar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.setForeground(Color.WHITE);
		btnSair.setFont(new Font("Gulim", Font.BOLD, 15));
		btnSair.setBackground(new Color(102, 255, 102));
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent clickSair) {
				
				int res = JOptionPane.showConfirmDialog(null, "Deseja mesmo cancelar o cadastro do aluno?", "Confirma��o", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
			
				if(res == 0)
				{
					limpaCampos();
				}
			}
		});
		btnSair.setBounds(224, 404, 118, 67);
		pCampos.add(btnSair);
		
		JButton btnfoto = new JButton("Foto");
		btnfoto.setForeground(Color.WHITE);
		btnfoto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					 //foto = new Escolher().buscar();
			
		}});
		btnfoto.setFont(new Font("Gulim", Font.BOLD, 15));
		btnfoto.setBackground(new Color(51, 153, 102));
		btnfoto.setBounds(140, 372, 202, 20);
		pCampos.add(btnfoto);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent evt) {
		
				 JOptionPane.showMessageDialog(null, "As informa��es do aluno a ser cadastrado foram perdidas.", "Confirma��o", JOptionPane.PLAIN_MESSAGE);
				limpaCampos();
			
			}});
	}
	
	public void telaAlterar(String nome, String RG, String endereco, String datanasc, String telefone, String RM, String datapag)
	{
		
		RM = this.RM;
		
		int resp = JOptionPane.showConfirmDialog(null, "Deseja mesmo alterar essas informa��es?", "Confirma��o",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		
		if(resp == 0){
			
			if(!txtNome.getText().equals("") && !txtRG.getText().equals("") && !txtTelefone.getText().equals("") &&  !txtEndereco.getText().equals("") && !txtDataNascimento.getText().equals("") && !txtDatapag.getText().equals(""))
			{
				//Inserir(txtNome.getText(), txtCPF.getText(), txtTelefone.getText(), txtEndereco.getText(), txtDataPagamento.getText(), (String) comboBox.getSelectedItem());
				
				if(verificaRestricoes() == true){
					
				ClasseComandos cmdCadastrar = new ClasseComandos();
					
				datanasc = transferePraDataAmericana(datanasc);
				
				cmdCadastrar.alterarAluno(nome, RG, endereco, datanasc, telefone, RM, datapag);
				
				txtNome.setText("");
				txtRG.setText("");
				txtTelefone.setText("");
				txtEndereco.setText("");
				txtDataNascimento.setText("");
				txtDatapag.setText("");
				dispose();
				
				}
				else{
					JOptionPane.showMessageDialog(this, erros, "Erro no cadastro", JOptionPane.ERROR_MESSAGE);
					erros = "Campos irregulares:\n";
				}
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Preencha todos os campos!", "Aten��o!", JOptionPane.ERROR_MESSAGE);
			}
		}
	}//Paretes�s do m�todo

	private void limpaCampos()
	{
	txtNome.setText("");
	txtRG.setText("");
	txtTelefone.setText("");
	txtEndereco.setText("");
	txtDataNascimento.setText("");
	txtDatapag.setText("");
	dispose();
	}
	
	private String transferePraDataAmericana(String data)
	{
		
		String dataaux = data.charAt(6) + "" + data.charAt(7) + "" + data.charAt(8) + "" + data.charAt(9) + "" + data.charAt(5) + "" + data.charAt(3) + "" + data.charAt(4) + "" + data.charAt(2) + "" + data.charAt(0) + "" + data.charAt(1); 
		
		return dataaux;
		
	}private String transferePraDataBRHUE(String data)
	{
		
		String dataaux = data.charAt(8) + "" + data.charAt(9) + "" + data.charAt(7) + "" + data.charAt(5) + "" + data.charAt(6) + "" + data.charAt(4) + "" + data.charAt(0) + "" + data.charAt(1) + "" + data.charAt(2) + "" + data.charAt(3); 
		
		return dataaux;
	}
	
	private boolean verificaRestricoes()
	{
		
		boolean nesseIf = true;
		
		if(txtNome.getText().length() < 40)
		{
			
		}else{
			txtNome.setBackground(new Color(255, 0, 0));
			erros += "Nome\n";
			nesseIf = false;
			}
		
		if(txtTelefone.getText().length() < 16)
		{
		}else{
			txtTelefone.setBackground(new Color(255, 0, 0));
			erros += "Telefone\n";
			nesseIf = false;
			}
		
		if(txtEndereco.getText().length() < 30)
		{
		}else{
			txtEndereco.setBackground(new Color(255, 0, 0));
			erros += "Endereco\n";
			nesseIf = false;
			}		
		
		return nesseIf;
		
	}
	
}
	

		
