package bean;

public class Mencao {

	private int RM;
	private String nome;
	private float teorica;
	private float pratica;
	
	
	public int getRM() {
		return RM;
	}
	public void setRM(int rM) {
		RM = rM;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public float getTeorica() {
		return teorica;
	}
	public void setTeorica(float teorica) {
		this.teorica = teorica;
	}
	public float getPratica() {
		return pratica;
	}
	public void setPratica(float pratica) {
		this.pratica = pratica;
	}
	public int getTurma() {
		return turma;
	}
	public void setTurma(int turma) {
		this.turma = turma;
	}
	public int getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(int disciplina) {
		this.disciplina = disciplina;
	}
	public int getSemestre() {
		return semestre;
	}
	public void setSemestre(int semestre) {
		this.semestre = semestre;
	}
	private int turma;
	private int disciplina;
	private int semestre;
		
}
