package bean;

import java.sql.Date;
import java.sql.Time;

public class Turma {
	
	// Fej�o
	
	private int cod;
	private int sala;
	private Date data;
	private int capacidade;
	private String periodo;
	private Time horarioIni;
	private Time horarioFin;
	private int duracao;
	private int semestre;
	private String disciplina;
	
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	public int getSala() {
		return sala;
	}
	public void setSala(int sala) {
		this.sala = sala;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public int getCapacidade() {
		return capacidade;
	}
	public void setCapacidade(int capacidade) {
		this.capacidade = capacidade;
	}
	public String getPeriodo() {
		return periodo;
	}
	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}
	public Time getHorarioIni() {
		return horarioIni;
	}
	public void setHorarioIni(Time horarioIni) {
		this.horarioIni = horarioIni;
	}
	public Time getHorarioFin() {
		return horarioFin;
	}
	public void setHorarioFin(Time horarioFin) {
		this.horarioFin = horarioFin;
	}
	public int getDuracao() {
		return duracao;
	}
	public void setDuracao(int duracao) {
		this.duracao = duracao;
	}
	public int getSemestre() {
		return semestre;
	}
	public void setSemestre(int semestre) {
		this.semestre = semestre;
	}
	public String getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}
		
}
