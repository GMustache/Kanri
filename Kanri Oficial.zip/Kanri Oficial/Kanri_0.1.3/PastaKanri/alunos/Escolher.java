package alunos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Escolher {
	String oi;
	public String buscar(){
		
		
		FileNameExtensionFilter filtro = new FileNameExtensionFilter("JPG", "JPG");
		JFileChooser esc = new JFileChooser();
		
	esc.setFileFilter(filtro);
	esc.setDialogTitle("Sua Imagem");
	
	int res = esc.showOpenDialog(null);
	
	if(res == JFileChooser.APPROVE_OPTION){
		
		File Caminho = new File(esc.getSelectedFile().getAbsolutePath());
		FileReader leitor;
		try{
			
			leitor = new FileReader(Caminho);
			BufferedReader leitura = new BufferedReader(leitor);
		
			
			 oi = esc.getSelectedFile().getPath().replaceAll("\\\\","/");
		
			
			leitura.close();
			leitor.close();
			
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
			
			
			
		}
		catch(IOException e){
			e.printStackTrace();
			
			
			
		}
		
			
			
		}
	return oi;
	
		
	}
	}
	
	

