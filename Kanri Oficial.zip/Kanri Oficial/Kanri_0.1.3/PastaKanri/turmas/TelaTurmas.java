package turmas;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;

import dao.ClasseComandos;
import bean.Turma;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Date;
import java.sql.Time;

public class TelaTurmas extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel dtm;
	
	private TelaTurmasCadastrar telaTurmasCadastrar;

	private TelaTurmasAlterar telaTurmasAlterar;
	
	
	public TelaTurmas() {
		setResizable(false);
		setTitle("Kanri - Turmas");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 800, 400);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel pTable = new JPanel();
		pTable.setBackground(Color.DARK_GRAY);
		pTable.setBounds(10, 0, 774, 303);
		contentPane.add(pTable);
		pTable.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 774, 292);
		pTable.add(scrollPane);

		dtm = new DefaultTableModel(new String[][]{{}},
				new String[] {
						"C�digo", "Disciplina", "Semestre", "Periodo", "Entrada as:", "Sa�da as:", "Sala", "Capacidade", "Data", "Dura��o"
				});
		
		telaAtualizarTurmas3(dtm);
		
		table = new JTable(dtm){	
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column) {
				
			return false;
			
			}
		};
		scrollPane.setViewportView(table);
		
		JPanel pButtons = new JPanel();
		pButtons.setBackground(Color.DARK_GRAY);
		pButtons.setBounds(10, 314, 774, 58);
		contentPane.add(pButtons);
		pButtons.setLayout(null);
		
		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent cadastraAluno) {
				
				abrirTelaTurmasCadastrar();
				
			}
		});
		btnCadastrar.setForeground(Color.WHITE);
		btnCadastrar.setFont(new Font("Gulim", Font.BOLD, 25));
		btnCadastrar.setBackground(new Color(102, 255, 102));
		btnCadastrar.setBounds(12, 12, 172, 34);
		pButtons.add(btnCadastrar);		
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {

				abrirTelaTurmasAlterar();
				
			}
		});
		btnAlterar.setForeground(Color.WHITE);
		btnAlterar.setFont(new Font("Gulim", Font.BOLD, 25));
		btnAlterar.setBackground(new Color(102, 255, 102));
		btnAlterar.setBounds(406, 12, 172, 34);
		pButtons.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				telaTurmasExcluir();
				
			}
		});
		btnExcluir.setForeground(Color.WHITE);
		btnExcluir.setFont(new Font("Gulim", Font.BOLD, 25));
		btnExcluir.setBackground(new Color(102, 255, 102));
		btnExcluir.setBounds(590, 12, 172, 34);
		pButtons.add(btnExcluir);
	}
	
	public DefaultTableModel telaAtualizarTurmas3(DefaultTableModel modelo){
		
		ClasseComandos cmdAtualizarTurmas3 = new ClasseComandos();
		cmdAtualizarTurmas3.atualizarTurmas3(modelo);
		return modelo;
		
	}
	
	private void telaTurmasExcluir()
	{
		try{
		Turma turma = new Turma();
		turma.setCod(Integer.parseInt((String) dtm.getValueAt(table.getSelectedRow(), 0)));
		
		ClasseComandos cmd = new ClasseComandos();
		cmd.excluirTurma(turma, dtm);
		}catch(IndexOutOfBoundsException e)
		{
			JOptionPane.showMessageDialog(null, "Seleciona uma linha para excluir", "Erro", JOptionPane.ERROR_MESSAGE);
		}
		}
	
	private void abrirTelaTurmasAlterar() 
	{
		try{
		Turma turma = new Turma();
		
		turma.setCod(Integer.parseInt((String) dtm.getValueAt(table.getSelectedRow(), 0)));
		turma.setDisciplina((String) dtm.getValueAt(table.getSelectedRow(), 1));
		turma.setSemestre(Integer.parseInt((String) dtm.getValueAt(table.getSelectedRow(), 2)));
		turma.setPeriodo((String) (dtm.getValueAt(table.getSelectedRow(), 3)));
		turma.setHorarioIni(Time.valueOf(((String) dtm.getValueAt(table.getSelectedRow(), 4))));
		turma.setHorarioFin(Time.valueOf((String) dtm.getValueAt(table.getSelectedRow(), 5)));
		turma.setSala(Integer.parseInt((String) dtm.getValueAt(table.getSelectedRow(), 6)));
		turma.setCapacidade(Integer.parseInt((String) dtm.getValueAt(table.getSelectedRow(), 7)));
		
		System.out.println((transferePraData((String) dtm.getValueAt(table.getSelectedRow(), 8))));
		turma.setData(Date.valueOf((transferePraData((String) dtm.getValueAt(table.getSelectedRow(), 8)))));
		
		turma.setDuracao(Integer.parseInt((String) dtm.getValueAt(table.getSelectedRow(), 9)));
			
	    telaTurmasAlterar = new TelaTurmasAlterar(turma, dtm);
		telaTurmasAlterar.setVisible(true);
		}
		catch(IndexOutOfBoundsException e)
		{
			JOptionPane.showMessageDialog(null, "Seleciona uma linha para alterar", "Erro", JOptionPane.ERROR_MESSAGE);
		}
		
	}
	
	private void abrirTelaTurmasCadastrar(){
		
		if(telaTurmasCadastrar == null)
		{
		telaTurmasCadastrar = new TelaTurmasCadastrar(dtm);
		}
		telaTurmasCadastrar.setVisible(true);
		
	}
	
	private String transferePraData(String data)
	{
		
		String dataaux = data.charAt(6) + "" + data.charAt(7) + "" + data.charAt(8) + "" + data.charAt(9) + "" + data.charAt(5) + "" + data.charAt(3) + "" + data.charAt(4) + "" + data.charAt(2) + "" + data.charAt(0) + "" + data.charAt(1); 
		
		return dataaux;
	}
}
