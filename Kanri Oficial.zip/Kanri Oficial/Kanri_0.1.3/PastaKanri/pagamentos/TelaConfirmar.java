package pagamentos;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;

import dao.ClasseComandos;

import java.awt.Font;
import java.sql.SQLException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaConfirmar extends JFrame {


	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;

	public TelaConfirmar(String Rm) throws ClassNotFoundException, SQLException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 395, 208);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Cancelar");
		btnNewButton.setBounds(10, 125, 175, 34);
		contentPane.add(btnNewButton);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClasseComandos cmd = new ClasseComandos();
				
					try {
						cmd.desatrasarMes(Rm);
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			dispose();
			
			}
		});
		btnOk.setBounds(194, 125, 175, 34);
		contentPane.add(btnOk);
		
		textField = new JTextField();
		textField.setBounds(180, 53, 189, 34);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblDigiteASenha = new JLabel("Digite a Senha:");
		lblDigiteASenha.setFont(new Font("Arial", Font.PLAIN, 14));
		lblDigiteASenha.setBounds(30, 45, 160, 50);
		contentPane.add(lblDigiteASenha);
		
		
	}
	
	
}
