package pagamentos;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import alunos.TelaAlunosCadastrar;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import dao.ClasseComandos;

import javax.swing.JButton;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.border.BevelBorder;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;

@SuppressWarnings({ "serial", "unused" })
public class TelaPagos extends JFrame {

	TelaAlunosCadastrar telaAlunosCadastrar;
	
	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel dtm;
	private String location;

	public void setLocation(String Location) {
		location = Location;
	}

	public TelaPagos() {
		
		setResizable(false);
		setTitle("Kanri - Gerenciar Alunos");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 531, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel pTable = new JPanel();
		pTable.setBackground(new Color(102, 255, 102));
		pTable.setBounds(10, 24, 500, 548);
		contentPane.add(pTable);
		pTable.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 16, 500, 521);
		pTable.add(scrollPane);
		
		dtm = new DefaultTableModel(new Object[][] {{
			
		}},
			new String[] {
				"RM", "Nome","Turma"
		});
		

		table = new JTable(dtm);
		table.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		scrollPane.setViewportView(table);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 525, 21);
		contentPane.add(menuBar);
		
		JMenuItem mnAtualizar = new JMenuItem("Atualizar");
		mnAtualizar.setFont(new Font("Copperplate Gothic Light", Font.PLAIN, 15));
		mnAtualizar.setForeground(Color.WHITE);
		mnAtualizar.setBackground(Color.DARK_GRAY);
		mnAtualizar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
		menuBar.add(mnAtualizar);
		mnAtualizar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent atualizarTelaAlunos) {
			
				ClasseComandos cmdAtualizar = new ClasseComandos();
			
				try {
					cmdAtualizar.atualizarPag(dtm);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
		
		ClasseComandos cmdAtualizar = new ClasseComandos();
		try {
			cmdAtualizar.atualizarPag(dtm);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	// Comandos internos
	
	private void abrirTelaAlunosCadastrar(DefaultTableModel dtm) throws ClassNotFoundException, SQLException{
		
		if(telaAlunosCadastrar == null)
		{
	     telaAlunosCadastrar = new TelaAlunosCadastrar(dtm);
		}
		 telaAlunosCadastrar.setVisible(true);
		
	}
	
	// Comandos externos
	
	public void telaExcluirAluno() throws ClassNotFoundException, SQLException
	{
			try{
				
				String selecionaRM = (String) dtm.getValueAt(table.getSelectedRow(), 0);
					
				System.out.println(selecionaRM);
				
				if(!selecionaRM.equals("") || !selecionaRM.equals(null)){
					
				
				int resp = JOptionPane.showConfirmDialog(null, "Deseja mesmo excluir esse aluno?", "Confirma��o",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				
				if(resp == 0){
				
							
						if(!selecionaRM.equals(""))
						{
							Class.forName("com.mysql.jdbc.Driver");

							String url = "jdbc:mysql://localhost:3306/u157866330_kanri";
					        
							Connection conexao = (Connection) DriverManager.getConnection(url, "root", "");

							Statement stExcluir = (Statement) conexao.createStatement();
					        stExcluir.executeUpdate("DELETE FROM `u157866330_kanri`.`alunos` WHERE `alunos`.`Rm` = " + selecionaRM + ";");
					        						
					        JOptionPane.showMessageDialog(null, "Aluno exclu�do!", "Sucesso!", JOptionPane.PLAIN_MESSAGE);
					        
					       
					        stExcluir.close();
						     conexao.close();
					    	
					    	
							
						
						  
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Preencha o campo!", "Aten��o!", JOptionPane.ERROR_MESSAGE);
						}	
				
					}
				}
			}//try
			catch(NullPointerException e){
				System.out.println("Nada acontece!");
			}

	}
}