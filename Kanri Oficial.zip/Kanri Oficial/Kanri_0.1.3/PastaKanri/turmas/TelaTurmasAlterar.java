package turmas;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import bean.Disciplina;
import bean.Turma;
import dao.ClasseComandos;

public class TelaTurmasAlterar extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtHorarioini;
	private JTextField txtHorariofin;
	private JTextField txtSala;
	private JTextField txtDuracao;
	private JTextField txtCapacidade;
	private JTextField txtData;
	
	List<Disciplina> listaDisciplinas = new ArrayList<Disciplina>();
	private JComboBox<String> jcbDisciplinas;
	Integer[] vetorSemestres;
	private JComboBox<Integer> jcbSemestres;
	private JComboBox<String> jcbPeriodo;

		public TelaTurmasAlterar(Turma turma, DefaultTableModel dtm) {
			
			setTitle("Kanri - Alterar");
			setResizable(false);
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			setBounds(100, 100, 375, 600);
			contentPane = new JPanel();
			contentPane.setBackground(Color.WHITE);
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(null);
			   
			JPanel pBody = new JPanel();
			pBody.setBackground(Color.DARK_GRAY);
			pBody.setBounds(0, 0, 369, 561);
			contentPane.add(pBody);
			pBody.setLayout(null);
			
			JLabel lblDisciplina = new JLabel("Disciplina:");
			lblDisciplina.setForeground(Color.WHITE);
			lblDisciplina.setFont(new Font("Gulim", Font.PLAIN, 15));
			lblDisciplina.setBounds(10, 11, 200, 20);
			pBody.add(lblDisciplina);
			
			ClasseComandos cmdAtualizaDisciplinas = new ClasseComandos();
			cmdAtualizaDisciplinas.atualizaDisciplinas(listaDisciplinas);
			
		    jcbDisciplinas = new JComboBox<String>();
		    
			for (Disciplina disciplina : listaDisciplinas) {
				jcbDisciplinas.addItem(disciplina.getNome());
			}
			jcbDisciplinas.setSelectedItem(turma.getDisciplina());
			
			for(int i = 0; i < listaDisciplinas.size(); i++)
			{			
					System.out.println(jcbDisciplinas.getSelectedItem());
			}
			
		    jcbDisciplinas.setForeground(new Color(102, 255, 102));
			jcbDisciplinas.setBackground(Color.WHITE);
			jcbDisciplinas.setBounds(10, 43, 347, 20);
			pBody.add(jcbDisciplinas);
			
			JLabel lblSemestre = new JLabel("Semestre:");
			lblSemestre.setForeground(Color.WHITE);
			lblSemestre.setFont(new Font("Gulim", Font.PLAIN, 15));
			lblSemestre.setBounds(10, 75, 200, 20);
			pBody.add(lblSemestre);
			
	    	vetorSemestres = new Integer[6];
			
			for(int i = 0; i < 6; i = i +1)
			{
				vetorSemestres[i] = i+1;
			}
			jcbSemestres = new JComboBox<Integer>(vetorSemestres);
			jcbSemestres.setSelectedItem(turma.getSemestre());
			jcbSemestres.setForeground(new Color(102, 255, 102));
			jcbSemestres.setBackground(Color.WHITE);
			jcbSemestres.setBounds(10, 107, 347, 20);
			pBody.add(jcbSemestres);
			
			JLabel lblPeriodo = new JLabel("Periodo:");
			lblPeriodo.setForeground(Color.WHITE);
			lblPeriodo.setFont(new Font("Gulim", Font.PLAIN, 15));
			lblPeriodo.setBounds(10, 139, 200, 20);
			pBody.add(lblPeriodo);
			
			jcbPeriodo = new JComboBox<String>();
			jcbPeriodo.addItem("Manh�");
			jcbPeriodo.addItem("Tarde");
			jcbPeriodo.addItem("Noite");
			jcbPeriodo.setSelectedItem(turma.getPeriodo());
			jcbPeriodo.setForeground(new Color(102, 255, 102));
			jcbPeriodo.setBackground(Color.WHITE);
			jcbPeriodo.setBounds(10, 171, 347, 20);
			pBody.add(jcbPeriodo);
			
			JLabel lblHorrio = new JLabel("Hor\u00E1rio:");
			lblHorrio.setForeground(Color.WHITE);
			lblHorrio.setFont(new Font("Gulim", Font.PLAIN, 15));
			lblHorrio.setBounds(10, 215, 110, 20);
			pBody.add(lblHorrio);
			
			JLabel lblDas = new JLabel("Das:");
			lblDas.setForeground(Color.WHITE);
			lblDas.setFont(new Font("Gulim", Font.PLAIN, 15));
			lblDas.setBounds(10, 247, 31, 20);
			pBody.add(lblDas);
			
			txtHorarioini = new JTextField();
			txtHorarioini.setBounds(44, 247, 110, 20);
			txtHorarioini.setText(turma.getHorarioIni().toString());
			pBody.add(txtHorarioini);
			txtHorarioini.setColumns(10);
			
			JLabel lblAtAs = new JLabel("At\u00E9 as:");
			lblAtAs.setForeground(Color.WHITE);
			lblAtAs.setFont(new Font("Gulim", Font.PLAIN, 15));
			lblAtAs.setBounds(166, 247, 53, 20);
			pBody.add(lblAtAs);
			
			txtHorariofin = new JTextField();
			txtHorariofin.setText(turma.getHorarioFin().toString());
			txtHorariofin.setColumns(10);
			txtHorariofin.setBounds(217, 247, 110, 20);
			pBody.add(txtHorariofin);
			
			JLabel lblSala = new JLabel("Sala:");
			lblSala.setForeground(Color.WHITE);
			lblSala.setFont(new Font("Gulim", Font.PLAIN, 15));
			lblSala.setBounds(10, 279, 110, 20);
			pBody.add(lblSala);
			
			txtSala = new JTextField();
			txtSala.setText(String.valueOf(turma.getSala()));
			txtSala.setColumns(10);
			txtSala.setBounds(10, 305, 60, 20);
			pBody.add(txtSala);
			
			JLabel lblDuracao = new JLabel("Dura\u00E7\u00E3o:");
			lblDuracao.setForeground(Color.WHITE);
			lblDuracao.setFont(new Font("Gulim", Font.PLAIN, 15));
			lblDuracao.setBounds(10, 337, 110, 20);
			pBody.add(lblDuracao);
			
			txtDuracao = new JTextField();
			txtDuracao.setText(String.valueOf(turma.getDuracao()));
			txtDuracao.setColumns(10);
			txtDuracao.setBounds(10, 363, 60, 20);
			pBody.add(txtDuracao);
			
			JLabel lblanos = new JLabel("(anos)");
			lblanos.setForeground(Color.WHITE);
			lblanos.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
			lblanos.setBounds(75, 363, 55, 20);
			pBody.add(lblanos);
			
			txtCapacidade = new JTextField();
			txtCapacidade.setText(String.valueOf(turma.getCapacidade()));
			txtCapacidade.setColumns(10);
			txtCapacidade.setBounds(10, 415, 60, 20);
			pBody.add(txtCapacidade);
			
			JLabel lblCapacidade = new JLabel("Capacidade:");
			lblCapacidade.setForeground(Color.WHITE);
			lblCapacidade.setFont(new Font("Gulim", Font.PLAIN, 15));
			lblCapacidade.setBounds(10, 389, 110, 20);
			pBody.add(lblCapacidade);
			
			JLabel lblData = new JLabel("Data:");
			lblData.setForeground(Color.WHITE);
			lblData.setFont(new Font("Gulim", Font.PLAIN, 15));
			lblData.setBounds(10, 447, 110, 20);
			pBody.add(lblData);
			
			txtData = new JTextField();
			txtData.setText(turma.getData().toString());
			txtData.setBounds(10, 473, 110, 20);
			pBody.add(txtData);
			txtData.setColumns(10);
		
			
			
			JButton btnCancelar = new JButton("Cancelar");
			btnCancelar.setFont(new Font("Gulim", Font.BOLD, 15));
			btnCancelar.setForeground(Color.WHITE);
			btnCancelar.setBackground(new Color(153, 255, 102));
			btnCancelar.setBounds(197, 523, 160, 26);
			pBody.add(btnCancelar);
			
			ClasseComandos cmdAtualizarEtalz = new ClasseComandos();
			cmdAtualizarEtalz.atualizarTurmas3(dtm);
			
			JButton btnCadastrar = new JButton("Alterar");
			btnCadastrar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent telaCadastrarTurma) {
					
					telaAlterarTurma(jcbPeriodo.getSelectedItem().toString(), jcbDisciplinas.getSelectedItem().toString(), dtm, turma.getCod());
				
				}
			});
			btnCadastrar.setFont(new Font("Gulim", Font.BOLD, 15));
			btnCadastrar.setForeground(Color.WHITE);
			btnCadastrar.setBackground(new Color(153, 255, 102));
			btnCadastrar.setBounds(12, 523, 160, 26);
			pBody.add(btnCadastrar);
			

			addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent evt) {
			
					limpaCampos();
					
				}
				});
				
		}


		private void telaAlterarTurma(String periodo, String disciplina, DefaultTableModel dtm, int cod) {

			ClasseComandos cmdCadastraTurma = new ClasseComandos();
			
			Turma turma = new Turma();
			
			turma.setCod(cod);
			turma.setHorarioIni(Time.valueOf(txtHorarioini.getText())); 
			turma.setHorarioFin(Time.valueOf(txtHorariofin.getText()));
			turma.setSala(Integer.parseInt(txtSala.getText()));
			turma.setDuracao(Integer.parseInt(txtDuracao.getText())); 
			turma.setData(Date.valueOf(txtData.getText()));	
			turma.setSemestre(Integer.parseInt(jcbSemestres.getSelectedItem().toString()));
			turma.setPeriodo(periodo);	
			turma.setCapacidade(Integer.parseInt(txtCapacidade.getText()));
			turma.setDisciplina(disciplina);
			
			cmdCadastraTurma.alterarTurma(turma, dtm, this);
			limpaCampos();
			
		}
		
		
		
		private void limpaCampos()
		{
		  jcbDisciplinas.setSelectedIndex(0);
		  jcbPeriodo.setSelectedIndex(0);
		  jcbSemestres .setSelectedIndex(0);
		  txtHorarioini.setText("");
		  txtHorariofin.setText("");
		  txtSala.setText("");
		  txtDuracao.setText("");
		  txtCapacidade.setText("");
		  txtData.setText("");
		}

}
