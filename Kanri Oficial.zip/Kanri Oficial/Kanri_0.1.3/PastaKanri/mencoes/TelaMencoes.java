package mencoes;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Color;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

import javax.swing.JComboBox;

import dao.ClasseComandos;
import bean.Turma;

public class TelaMencoes extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel dtm;
	private JTextField txtRM;
	private JTextField txtNome;
	private JTextField txtSemestre;
	private JTextField txtDisciplina;
	private JTextField txtConceito;
	private JRadioButton rdbtnPratica;
	private JRadioButton rdbtnTeorica;
	private JButton btnCadastrarMencao;
	private JPanel pFields;
	
	private boolean emCadastro = false;
	
	private List<Turma> listadeturmas = new ArrayList<Turma>();
	
	int turma;
	private JLabel lblDisciplina;
	
	public TelaMencoes() {
		
		setTitle("Kanri - Men\u00E7\u00F5es");
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 600);	

		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		ClasseComandos cmdAtualizaTurmas = new ClasseComandos();
		cmdAtualizaTurmas.atualizarTurmas(listadeturmas);
		
		JComboBox<Integer> jcbTurmas = new JComboBox<Integer>();
		for(Turma turma : listadeturmas)
		{
				jcbTurmas.addItem(turma.getCod());
		}
		turma = (int) jcbTurmas.getSelectedItem();
		menuBar.add(jcbTurmas);
		jcbTurmas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent escolheTurma) {
				
				turma = (int) jcbTurmas.getSelectedItem();
				telaAtualizarTabela(dtm, turma);
				
			}
		});
		jcbTurmas.setForeground(new Color(102, 255, 51));
		jcbTurmas.setFont(new Font("Copperplate Gothic Light", Font.PLAIN, 15));
		jcbTurmas.setBackground(Color.GRAY);
		turma = (int) jcbTurmas.getSelectedItem();
		
		JMenuItem mntmAtualizar = new JMenuItem("Atualizar");
		mntmAtualizar.setBackground(Color.DARK_GRAY);
		mntmAtualizar.setFont(new Font("Copperplate Gothic Light", Font.PLAIN, 15));
		mntmAtualizar.setForeground(Color.WHITE);
		mntmAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent telaAtualizarTabela) {
				
				telaAtualizarTabela(dtm, turma);
			}
		});
		
		mntmAtualizar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
		menuBar.add(mntmAtualizar);
		
		
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel pTable = new JPanel();
		pTable.setBounds(10, 11, 700, 424);
		contentPane.add(pTable);
		pTable.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 700, 423);
		pTable.add(scrollPane);
		
		dtm = new DefaultTableModel(new Object[][] {{ null			
			}},
				new String[] {"RM","Nome","Nota te�rica", "Nota pr�tica", "Disciplina", "Semestre"
				
			});
		
		table = new JTable(dtm){
	
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int linha, int coluna)
			{
				return false;
			};
		};
		scrollPane.setViewportView(table);
		
		JPanel pButtons = new JPanel();
		pButtons.setBackground(Color.DARK_GRAY);
		pButtons.setBounds(10, 447, 700, 90);
		contentPane.add(pButtons);
		pButtons.setLayout(null);
		
		JButton btnNovaMencao = new JButton("Nova men\u00E7\u00E3o");
		btnNovaMencao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent clickNovoAluno) {
				
				
				habilitaCampos();	
				
			}
		});
		btnNovaMencao.setFont(new Font("Gulim", Font.BOLD, 25));
		btnNovaMencao.setForeground(Color.WHITE);
		btnNovaMencao.setBackground(new Color(102, 255, 51));
		btnNovaMencao.setBounds(12, 12, 676, 66);
		pButtons.add(btnNovaMencao);
		
		pFields = new JPanel();
		pFields.setBackground(Color.DARK_GRAY);
		pFields.setBounds(720, 11, 264, 526);
		contentPane.add(pFields);
		pFields.setLayout(null);
		
		JLabel lblRM = new JLabel("RM:");
		lblRM.setForeground(Color.WHITE);
		lblRM.setFont(new Font("Gulim", Font.BOLD, 15));
		lblRM.setBounds(10, 11, 110, 14);
		pFields.add(lblRM);
		
		txtRM = new JTextField();
		txtRM.setEnabled(false);
		txtRM.setBounds(10, 36, 76, 20);
		pFields.add(txtRM);
		txtRM.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setForeground(Color.WHITE);
		lblNome.setFont(new Font("Gulim", Font.BOLD, 15));
		lblNome.setBounds(10, 67, 110, 14);
		pFields.add(lblNome);
		
		txtNome = new JTextField();
		txtNome.setEnabled(false);
		txtNome.setBounds(10, 92, 244, 20);
		pFields.add(txtNome);
		txtNome.setColumns(10);
		
		lblDisciplina = new JLabel("Disciplina:");
		lblDisciplina.setForeground(Color.WHITE);
		lblDisciplina.setFont(new Font("Gulim", Font.BOLD, 15));
		lblDisciplina.setBounds(10, 123, 110, 14);
		pFields.add(lblDisciplina);
		
		txtDisciplina = new JTextField();
		txtDisciplina.setEnabled(false);
		txtDisciplina.setBounds(10, 148, 76, 20);
		pFields.add(txtDisciplina);
		txtDisciplina.setColumns(10);
		
		JLabel lblSemestre = new JLabel("Semestre:");
		lblSemestre.setForeground(Color.WHITE);
		lblSemestre.setFont(new Font("Gulim", Font.BOLD, 15));
		lblSemestre.setBounds(10, 179, 110, 14);
		pFields.add(lblSemestre);
		
		txtSemestre = new JTextField();
		txtSemestre.setEnabled(false);
		txtSemestre.setBounds(10, 204, 110, 20);
		pFields.add(txtSemestre);
		txtSemestre.setColumns(10);
		
		rdbtnPratica = new JRadioButton("Pr\u00E1tica");
		rdbtnPratica.setEnabled(false);
		rdbtnPratica.setFont(new Font("Gulim", Font.BOLD, 15));
		rdbtnPratica.setForeground(Color.WHITE);
		rdbtnPratica.setBackground(Color.DARK_GRAY);
		rdbtnPratica.setBounds(149, 325, 109, 23);
		pFields.add(rdbtnPratica);
		
		rdbtnTeorica = new JRadioButton("Te\u00F3rica");
		rdbtnTeorica.setEnabled(false);
		rdbtnTeorica.setFont(new Font("Gulim", Font.BOLD, 15));
		rdbtnTeorica.setForeground(Color.WHITE);
		rdbtnTeorica.setBackground(Color.DARK_GRAY);
		rdbtnTeorica.setBounds(10, 325, 109, 23);
		pFields.add(rdbtnTeorica);
		
		ButtonGroup clubinhoDoBotao = new ButtonGroup();
		clubinhoDoBotao.add(rdbtnPratica);
		clubinhoDoBotao.add(rdbtnTeorica);
		
		JLabel lblConceito = new JLabel("Conceito:");
		lblConceito.setForeground(Color.WHITE);
		lblConceito.setFont(new Font("Gulim", Font.BOLD, 15));
		lblConceito.setBounds(10, 235, 110, 14);
		pFields.add(lblConceito);
		
		txtConceito = new JTextField();
		txtConceito.setEnabled(false);
		txtConceito.setBounds(10, 260, 76, 20);
		pFields.add(txtConceito);
		txtConceito.setColumns(10);
		
		btnCadastrarMencao = new JButton("Cadastrar");
		btnCadastrarMencao.setEnabled(false);
		btnCadastrarMencao.setForeground(Color.WHITE);
		btnCadastrarMencao.setFont(new Font("Gulim", Font.BOLD, 30));
		btnCadastrarMencao.setBackground(new Color(102, 255, 51));
		btnCadastrarMencao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent clickCadastrarMencao) {
				
			if(!txtConceito.getText().equals("") && !txtConceito.getText().equals(""))
			{
				try{
					
					telaCadastraMencao(Float.parseFloat(txtConceito.getText()), Integer.parseInt(jcbTurmas.getSelectedItem().toString()), Integer.parseInt(txtRM.getText()));											
				
				}catch(NumberFormatException e) 
				{
					JOptionPane.showMessageDialog(null, "Insira apenas n�meros!", "Erro ao cadastrar men��o!", JOptionPane.ERROR_MESSAGE);	
				}
				
			}
			else{
				JOptionPane.showMessageDialog(null, "Insira o conceito!", "Erro ao cadastrar men��o!", JOptionPane.ERROR_MESSAGE);	
			}
			
		}});
		btnCadastrarMencao.setBounds(10, 475, 244, 40);
		pFields.add(btnCadastrarMencao);
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent evt) {
		
				jcbTurmas.setSelectedIndex(0);
				
			}
			});

		telaAtualizarTabela(dtm, turma);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent evt) {
		
			if(emCadastro == true)
			{
				 JOptionPane.showMessageDialog(null, "As informa��es da men��o foram perdidas.", "Confirma��o", JOptionPane.PLAIN_MESSAGE);
				desabilitaCampos();
				
			}
			
			}});
		
		getRootPane().setDefaultButton(btnCadastrarMencao);
		
	}
	

	// 1 F(EEEEEEEEEEEEEEELS AJIEEHAEHAEHUAHUHUHAEHUAEHUEAHUEUAHUEHAUEAHUEHUAHEHAUHEUAHEUHAUEHAUHEAHUHEUAHE AKSLKDALSDAJSJDKLAJAEJWEHIUQUI�RUIOAARHORHIOAARHIOASRJASTJASFJDFANHUUIFSIAOUHR)
	// F DE FUNCIONAL TALGSDN�ARIPWEIPQIRPWORJKRIOPJQWIRJWHJORQHRHQURIQRHQ ai que sono porra
	
	private void telaCadastraMencao(float conceito, int turma, int RM)
	{	
		if(conceito >= 0 && conceito <= 10)
		{
		ClasseComandos cmdCadastraMencao = new ClasseComandos();
		
		System.out.println("WTF rodou o m�todo");
		
		if(rdbtnPratica.isSelected())
		{
			System.out.println("Pratica selecionado");
			
			int res = JOptionPane.showConfirmDialog(null, "Deseja mesmo cadastrar essa men��o?", "Confirma��o", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
			
			System.out.println("res:" + res);
			
			if(res == 0)
			{
				System.out.println("PASSEI PORRA P");
				cmdCadastraMencao.cadastrarMencao(0f, conceito, turma, RM);
			}
		}
		
		else{
			if(rdbtnTeorica.isSelected())
			{
				
				System.out.println("teorica selecionada");
				int res = JOptionPane.showConfirmDialog(null, "Deseja mesmo cadastrar essa men��o?", "Confirma��o", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
			
				System.out.println("res:" + res);
				
				if(res == 0)
				{
				System.out.println("PASSEI PORRA T");
				cmdCadastraMencao.cadastrarMencao(conceito, 0f, turma, RM);
				}
			}
			else{
				JOptionPane.showMessageDialog(null, "Selecione o tipo da nota!", "Erro ao cadastrar men��o!", JOptionPane.ERROR_MESSAGE);
			}
		}
		
		
		desabilitaCampos();
		telaAtualizarTabela(dtm, turma);
		
		}else{
			JOptionPane.showMessageDialog(null, "Insira uma nota de 0 a 10!", "Erro ao cadastrar men��o!", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	private void desabilitaCampos()
	{
		txtRM.setText("");
		txtRM.setEnabled(false);
		txtNome.setText("");
		txtNome.setEnabled(false);
		txtDisciplina.setText("");
		txtDisciplina.setEnabled(false);
		txtSemestre.setText("");
		txtSemestre.setEnabled(false);
		txtConceito.setText("");
		txtConceito.setEnabled(false);
		rdbtnPratica.setSelected(false);
		rdbtnPratica.setEnabled(false);
		rdbtnTeorica.setSelected(false);
		rdbtnTeorica.setEnabled(false);
		btnCadastrarMencao.setEnabled(false);
		emCadastro = false;
		}
	
	private void habilitaCampos(){
		
	try{
		txtRM.setText(dtm.getValueAt(table.getSelectedRow(), 0).toString());
		txtNome.setText(dtm.getValueAt(table.getSelectedRow(), 1).toString());
		txtDisciplina.setText(dtm.getValueAt(table.getSelectedRow(), 4).toString());
		txtSemestre.setText(dtm.getValueAt(table.getSelectedRow(), 5).toString());
		txtConceito.setEnabled(true);
		rdbtnPratica.setEnabled(true);
		rdbtnTeorica.setEnabled(true);	
		btnCadastrarMencao.setEnabled(true);
		emCadastro = true;
		}catch(IndexOutOfBoundsException e)
		{
			
			JOptionPane.showMessageDialog(this, "Selecione uma linha para a nova nota!", "Erro ao cadastrar men��o!", JOptionPane.ERROR_MESSAGE);
		}
	}
		
	private void telaAtualizarTabela(DefaultTableModel modelo, int turma)
	{
		ClasseComandos cmdAtualizar = new ClasseComandos();
		cmdAtualizar.atualizarMencao(modelo, turma);
	}
}
